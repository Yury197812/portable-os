# MIMO processed

OCULUS processing reports and accepted/rejected disposition records for completed MIMO batches.

# MIMO quarantine

Conflicting, unsupported, unsafe, legally uncertain, duplicate or non-transferable MIMO material is recorded here with reasons instead of silently discarded or promoted.

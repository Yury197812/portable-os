# MIMO — external research/intake zone

Эта папка принадлежит MIMO и предназначена только для его результатов по проекту OCULUS Platform Skill Factory / portable software.

## Правило

MIMO складывает новые результаты в `MIMO/inbox/<batch_id>/`.

OCULUS не считает содержимое `MIMO/` каноном автоматически. Каждый batch проходит:

`INTAKE -> INVENTORY -> CLAIMS -> PROVENANCE -> CONFLICT -> DEDUP -> VALIDATION -> BATTLECHECK -> PROMOTION`

Только после этого подтверждённые изменения переносятся в код, книгу, Skill Registry и production-артефакты.

## Зоны

- `inbox/` — новые необработанные результаты MIMO.
- `processed/` — batch после полного OCULUS-прохода.
- `quarantine/` — неподтверждённые, конфликтные, небезопасные или неприменимые материалы.

## Минимальный batch manifest

Желательно, чтобы каждый batch содержал `MIMO_MANIFEST.md` или `MIMO_MANIFEST.json` с:

- `batch_id`
- `created_at`
- `source/tool/version`
- `goal`
- `files`
- `claims`
- `assumptions`
- `tests_performed`
- `known_limits`

Сырые результаты MIMO не редактируются задним числом: corrections оформляются новым batch или отдельным amendment-файлом.

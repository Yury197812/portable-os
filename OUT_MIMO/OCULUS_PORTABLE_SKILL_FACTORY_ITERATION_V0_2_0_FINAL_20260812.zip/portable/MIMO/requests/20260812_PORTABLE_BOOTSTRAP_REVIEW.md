# REQUEST MIMO-20260812-PORTABLE-001

Status: `OPEN`

## Goal
Review and improve the first OCULUS Portable Skill Factory software scaffold without sacrificing correctness, evidence, provenance, reproducibility or rollback.

## Read first

1. `README.md`
2. `book/OCULUS_PORTABLE_SOFTWARE_BOOK.md`
3. `internal/`
4. `api/openapi.yaml`
5. `skills/system/`
6. `build/` and `portable/`
7. `MIMO/COMMUNICATION.md`

## Tasks for MIMO

### A. Architecture review
Find incorrect, fragile, slow or overcomplicated decisions in the current portable-first architecture.

Focus on:
- Windows portable behavior;
- Go runtime layout;
- local API/dashboard;
- local state;
- skill registry;
- network policy;
- clean-machine execution;
- future migration path to a fuller evidence/skill engine.

### B. Acceleration research
Propose mechanisms that materially accelerate the system **without reducing accuracy**.

Priority areas:
- deterministic routing;
- content-addressed cache;
- incremental/diff rebuilds;
- batching;
- bounded parallelism;
- provider-aware concurrency;
- precomputed indexes;
- memoization with evidence binding;
- fast negative filters;
- structured extraction before LLM fallback;
- benchmark methodology for `slow_reference` vs `fast_candidate`.

For every acceleration proposal specify:
- what gets faster;
- why correctness should remain equivalent;
- failure modes;
- quality oracle;
- rollback/fallback;
- what evidence is needed before promotion.

### C. Internet/research layer
Design a provider-adapter architecture for controlled Internet research.

Do not assume unlimited scraping rights. Separate:
- official API;
- permitted public web access;
- first-party analytics;
- manual/user-supplied evidence;
- forbidden/uncertain collection paths.

### D. Storage evolution
Compare viable portable storage approaches for the next phase:
- append-only JSONL + indexes;
- SQLite-compatible pure-Go options;
- embedded KV stores;
- hybrid content-addressed filesystem.

Score them for portability, crash safety, migration, queryability, provenance graph support, concurrency, backup/restore and dependency risk.

### E. Skill extraction
Review `skills/system/` for duplicates, missing capabilities and bad boundaries.

Return suggested actions using only:
`REUSE`, `EXTEND`, `MERGE`, `CREATE_NEW`, `REJECT`.

### F. Battlecheck
Try to break the current architecture with at least these scenarios:
- moved portable folder;
- missing/invalid config;
- denied host;
- DNS/network timeout;
- oversized response;
- corrupt event line;
- partial disk write;
- duplicate skill IDs;
- simultaneous research tasks;
- stale cached evidence;
- interrupted update;
- MIMO batch with conflicting claims.

## Deliverable
Create a new immutable batch under:

`MIMO/inbox/<batch_id>/`

with at minimum:

- `MIMO_MANIFEST.md`
- `ARCHITECTURE_REVIEW.md`
- `ACCELERATION_WITHOUT_ACCURACY_LOSS.md`
- `INTERNET_ADAPTERS.md`
- `STORAGE_RECOMMENDATION.md`
- `SKILL_ACTIONS.md`
- `BATTLECHECK.md`
- `NEXT_PATCH_PLAN.md`

Do not edit OCULUS canonical files directly. OCULUS will ingest, validate and promote accepted changes.

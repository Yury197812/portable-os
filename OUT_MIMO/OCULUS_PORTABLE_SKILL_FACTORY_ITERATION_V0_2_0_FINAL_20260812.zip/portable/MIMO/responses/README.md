# MIMO responses

Optional concise acknowledgements and response notes. Raw research deliverables belong in `MIMO/inbox/<batch_id>/`.

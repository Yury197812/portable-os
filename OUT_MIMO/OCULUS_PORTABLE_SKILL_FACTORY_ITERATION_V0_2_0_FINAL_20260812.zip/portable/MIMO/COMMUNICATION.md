# OCULUS ↔ MIMO COMMUNICATION

This file is the durable coordination protocol between OCULUS and MIMO.

## Channels

- `MIMO/requests/` — OCULUS writes research/review requests for MIMO.
- `MIMO/inbox/<batch_id>/` — MIMO places new raw result batches.
- `MIMO/responses/` — optional concise response/acknowledgement files referencing request IDs.
- `MIMO/processed/` — OCULUS moves/copies processing reports here after full validation.
- `MIMO/quarantine/` — material not safe or justified for promotion.

## Request lifecycle

`OPEN → ACKNOWLEDGED → IN_PROGRESS → DELIVERED → OCULUS_VALIDATING → ACCEPTED/PARTIAL/QUARANTINED`

MIMO should never overwrite an old batch. Corrections are a new batch or amendment.

## Required response linkage

Every response/batch should state:

- `request_id`;
- `batch_id`;
- MIMO model/tool/version if available;
- created time;
- source list;
- claims/findings;
- implementation suggestions;
- tests performed;
- known limits/uncertainties.

## Accuracy rule

MIMO is encouraged to optimize research speed, parallelize independent investigation and reuse previous evidence, but it must not trade away citation/provenance quality for speed.

OCULUS will independently deduplicate, validate and battlecheck promoted material.

## Current request

See `MIMO/requests/20260812_PORTABLE_BOOTSTRAP_REVIEW.md`.

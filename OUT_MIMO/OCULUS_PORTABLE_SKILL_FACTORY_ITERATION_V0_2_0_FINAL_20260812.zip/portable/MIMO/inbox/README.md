# MIMO inbox

MIMO places each immutable delivery under `MIMO/inbox/<batch_id>/` and links it to an OCULUS request ID.

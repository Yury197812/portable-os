@echo off
setlocal
cd /d "%~dp0"
if not exist "config\config.json" (
  echo Missing config\config.json
  exit /b 1
)
start "OCULUS Portable" /b oculus-portable.exe -config config\config.json
ping 127.0.0.1 -n 2 >nul
start "" http://127.0.0.1:8787
endlocal

# OCULUS Portable Skill Factory

Current iteration: **v0.2.0 — Atomic Resolve/Evidence Vertical Slice**

Portable-first software for researching, resolving, validating, applying and continuously improving platform skills for Yandex, Google, VK, Telegram and Dzen.

## Product goal

Build a Windows-first portable application that runs from a folder without installation, exposes a local dashboard/API, has controlled outbound Internet access, keeps local reproducible state, and uses OCULUS skill/evidence/provenance/validation loops for every important decision.

## Core rule

**Speed is allowed only behind accuracy gates.** Caching, batching, bounded parallelism, deterministic fast paths and incremental processing may reduce latency, but must not reduce evidence completeness, provenance, reproducibility, validation depth or rollback capability.

## v0.2.0 working vertical

The current executable includes:

- deterministic typed Task Intake + SHA-256 fingerprint;
- filesystem `SKILL.md` registry + SHA-256;
- resolve-first Skill Resolver v1;
- immutable content-addressed Evidence Store;
- tamper verification on evidence read;
- controlled outbound HTTP/HTTPS with allowlist and redirect re-check;
- deterministic non-blocking MIMO inbox scanner;
- append-only runtime event trace;
- JSON reference-vs-candidate equivalence primitive;
- local API and dashboard;
- Windows x64 cross-build and GitHub Actions quality pipeline.

## Repository map

- `cmd/oculus-portable/` — executable entry point.
- `internal/tasks/` — typed task normalization and deterministic fingerprint.
- `internal/skills/` — local registry and resolve-first logic.
- `internal/evidence/` — immutable content-addressed evidence.
- `internal/internet/` — controlled outbound Internet.
- `internal/mimo/` — deterministic MIMO intake scanner.
- `internal/quality/` — equivalence/accuracy primitives.
- `internal/state/` — append-only runtime trace.
- `dashboard/` — local web UI.
- `api/` — OpenAPI contract.
- `config/` — portable configuration templates.
- `skills/` — reusable executable operating skills.
- `book/` — living OCULUS book; every full cycle starts from Chapter 1.
- `build/` — reproducible Windows build and packaging scripts.
- `portable/` — portable launch assets.
- `MIMO/` — isolated external MIMO research/intake zone.

## Build on Windows

Run:

```bat
build\build_windows.cmd
```

It runs tests, builds `oculus-portable.exe`, copies dashboard/skills/book/API/MIMO assets, computes SHA-256 and creates:

`dist\OCULUS_PORTABLE_v0.2.0.zip`

## Run portable build

1. Extract the ZIP to any writable folder.
2. Review `config/config.json` and explicitly allow only required Internet hosts.
3. Run `run.cmd`.
4. Open `http://127.0.0.1:8787`.

## OCULUS development cycle

`CHAPTER_1_RECHECK → MIMO_CHECK → INVENTORY → ATOMIZE → INVARIANTS → SKILL_RESOLVE → IMPLEMENT → TEST → BATTLECHECK → BOOK_REBUILD → SKILL_EXTRACTION → SKILL_DEDUP → SKILL_REBUILD → APPLY_SKILLS → RELEASE_ZIP`

MIMO is checked on every iteration but never blocks development. If no new batch exists, OCULUS continues immediately.

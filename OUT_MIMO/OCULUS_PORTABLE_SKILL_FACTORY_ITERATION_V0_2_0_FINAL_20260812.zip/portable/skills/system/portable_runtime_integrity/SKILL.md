# Portable Runtime Integrity

## Purpose
Keep the product runnable from a copied folder without hidden machine-specific state and make every OCULUS iteration handoff a self-contained reproducible ZIP.

## When to use
Use for every portable build, every release candidate, every end-of-iteration handoff and every relocation/rollback test.

## Procedure
1. Resolve runtime paths relative to the portable working directory or executable bundle.
2. Keep mutable state under the portable data directory unless explicitly configured otherwise.
3. Avoid mandatory registry/services/system-wide installation.
4. Build the target native executable from a recorded commit/toolchain.
5. Assemble required runtime assets: config, dashboard, skills, book, API contract, MIMO zones and empty writable data/evidence directories.
6. Compute executable and release hashes.
7. Produce a full iteration bundle containing both the portable runnable product and the corresponding source/book/skills/release evidence.
8. Package the bundle as one versioned ZIP at the end of every completed iteration.
9. Produce a manifest containing commit, file paths, sizes and hashes.
10. Test on a clean Windows environment when a Windows runner/environment is available.
11. Move/copy the folder and rerun smoke tests.
12. Verify config, skills, dashboard, MIMO and state discovery after relocation.
13. Record runtime/toolchain/build provenance.

## Atomic nucleus
A release is portable only if all required runtime state and knowledge travel with the folder/ZIP and no hidden machine-specific dependency is required for basic startup.

## Acceleration rule
Release packaging may reuse unchanged hashed assets and incremental manifests, but the final ZIP must still be verifiably equivalent to a clean assembly from the recorded source commit.

## Quality gates
- CI tests pass before packaging;
- Windows executable builds successfully;
- full iteration artifact is produced;
- clean-machine start succeeds before claiming production portability;
- relocation succeeds before claiming relocation validation;
- no undisclosed absolute paths;
- integrity manifest verifies;
- rollback is folder-level reproducible.

# Bounded Parallelism

## Purpose
Run independent work concurrently without losing determinism, rate control, traceability or system stability.

## Use when
Multiple research sources, validation cases or independent tasks can execute without shared mutable ordering dependencies.

## Procedure
1. Prove task independence or define explicit synchronization points.
2. Set a hard worker/concurrency budget.
3. Preserve stable input IDs and output ordering independent of completion order.
4. Apply provider rate limits and cancellation.
5. Collect each worker result with provenance and error state.
6. Aggregate only after all required workers reach a terminal state.
7. Compare with sequential reference behavior on test corpora.

## Quality gates
- no dropped worker result;
- no race-dependent semantic output;
- no provider-limit bypass;
- deterministic aggregation;
- bounded memory and goroutine/thread count.

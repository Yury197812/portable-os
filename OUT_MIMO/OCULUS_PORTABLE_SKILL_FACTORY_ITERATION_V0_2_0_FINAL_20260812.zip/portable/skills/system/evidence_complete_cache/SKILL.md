# Evidence-Complete Cache

## Purpose
Reuse expensive research/extraction results without detaching conclusions from their source evidence.

## Cache key must include
- normalized request/input hash;
- source identity/version where known;
- collector/parser version;
- policy version;
- relevant scope/platform metadata.

## Cached payload must retain
- output;
- evidence refs;
- provenance refs;
- source snapshot/hash;
- producer version;
- created/validated timestamps;
- expiry/invalidation metadata.

## Procedure
1. Derive content-addressed key.
2. Validate cache metadata before reuse.
3. Reject entries with missing evidence/provenance.
4. Revalidate stale entries against freshness policy.
5. On hit, emit a cache-reuse event linked to original evidence.
6. On miss, execute full producer and atomically store complete result.

## Quality gates
A cache hit must never be semantically weaker or less auditable than recomputation.

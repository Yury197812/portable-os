# Atomic Decomposition Before Implementation

## Purpose
Prevent large requirements, architectural ideas and book chapters from being implemented as vague monoliths. Decompose them until each unit has an explicit invariant, evidence need, failure mode and executable responsibility.

## When to use
Use at the start of every OCULUS book/development iteration, before architecture changes, and before promoting a new reusable skill.

## Procedure
1. State the user-visible goal and measurable outcome.
2. Split the goal into system substances: data, control, policy, evidence, runtime, UI, storage, network, quality and release.
3. Split each substance into molecules: independently testable subsystems.
4. Split each molecule into atoms: functions/contracts/state transitions that can be reasoned about and tested independently.
5. For every atom define:
   - input;
   - output;
   - invariant;
   - side effects;
   - provenance/evidence requirements;
   - failure modes;
   - rollback/recovery behavior;
   - performance budget where relevant.
6. Identify the atomic nucleus: the smallest invariant whose violation makes the feature semantically incorrect.
7. Map atoms back to code paths, tests, book sections and skills.
8. Merge duplicate atoms before implementation.
9. Rebuild the feature from validated atoms upward.

## Atomic nucleus
No implementation unit may be considered complete if its correctness invariant cannot be stated and tested.

## Acceleration rule
Decomposition may be parallelized only across independent molecules. Coupled atoms retain a single ordered owner/path until their shared invariants are proven.

## Quality gates
- Every important implementation has at least one explicit invariant.
- Every new skill maps to a repeated transferable atom or molecule rather than a one-off code fragment.
- Decomposition must reduce ambiguity, not merely produce more labels.

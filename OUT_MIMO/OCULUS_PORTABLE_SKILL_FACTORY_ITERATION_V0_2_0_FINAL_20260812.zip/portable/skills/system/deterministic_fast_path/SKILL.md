# Deterministic Fast Path

## Purpose
Resolve obvious cases cheaply before invoking expensive semantic/LLM stages.

## Use when
Inputs contain stable IDs, exact hashes, normalized names, known metadata or previously validated routing keys.

## Procedure
1. Normalize only fields whose normalization rules are versioned and deterministic.
2. Check exact stable ID.
3. Check content hash.
4. Check exact normalized key plus required platform/surface scope.
5. Return immediately only when the match is unambiguous and policy allows that action.
6. Escalate all ambiguous cases to the slower resolver.
7. Record which deterministic rule fired.

## Never use for
- irreversible merge on fuzzy similarity;
- resolving conflicting evidence;
- promotion to canonical without validation.

## Quality gates
Fast-path result must equal the reference resolver on the validation corpus for all cases eligible for this path.

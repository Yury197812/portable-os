# Resolve Before Research

## Purpose
Prevent unnecessary research and duplicate skill creation by resolving existing capabilities before expensive collection, embeddings, LLM arbitration or new skill compilation.

## When to use
Use immediately after deterministic task intake and before any research job is scheduled.

## Procedure
1. Search exact skill ID and normalized name.
2. Apply deterministic metadata/token prefilter to produce a bounded candidate set.
3. Return `REUSE` immediately for an exact unambiguous match that satisfies required scope.
4. Return `EXTEND` when a strong candidate exists but capability/scope gaps remain.
5. Return `MERGE_CANDIDATE` only as a review state; deterministic logic never performs an irreversible merge.
6. Return `CREATE_NEW` only when no existing skill covers the required capability.
7. Escalate ambiguous cases to deeper lexical/semantic/structural comparison or LLM arbitration.
8. Preserve resolver candidates, scores and reasons in the trace.

## Atomic nucleus
No new skill may be created until the system has demonstrated that reuse or extension is insufficient.

## Acceleration rule
The first resolver stage must be cheap, deterministic and bounded. Expensive semantic search is activated only after the deterministic stage fails to resolve confidently.

## Quality gates
- Exact matches are deterministic.
- Ambiguity never triggers automatic merge.
- Candidate ranking is reproducible for the same registry snapshot.
- Every `CREATE_NEW` decision records the registry/evidence snapshot against which the gap was evaluated.

# Chapter One Architecture Recheck

## Purpose
Force every major OCULUS cycle to challenge the project's foundational assumptions before optimizing downstream details.

## Use when
Starting a new release cycle, ingesting a major MIMO batch, changing platform scope, or introducing a new runtime/storage/network architecture.

## Procedure
1. Re-read the current Chapter 1 product goal and invariants.
2. Inventory what is actually implemented now.
3. List assumptions that changed since the previous release.
4. Identify architecture decisions that no longer follow from current goals.
5. Separate confirmed facts from inference, hypothesis, experiment and decision.
6. Re-run risk and dependency audit from the product boundary inward.
7. Resolve applicable existing skills before proposing new process rules.
8. Produce a versioned decision diff.
9. Only then continue implementation/optimization.

## Quality gates
- no downstream optimization before product-goal consistency check;
- changed assumptions explicitly recorded;
- superseded decisions retained in history rather than silently rewritten.

# Reference vs Candidate Equivalence Gate

## Purpose
Prevent a faster or newer implementation from replacing the trusted path until equivalence is demonstrated.

## Procedure
1. Freeze a labeled validation corpus including edge and adversarial cases.
2. Run the current trusted reference implementation.
3. Run the candidate implementation with identical inputs.
4. Compare outputs using exact assertions where possible and explicit semantic or numeric tolerances where exact equality is inappropriate.
5. Compare evidence/provenance coverage separately from final output quality.
6. Classify every disagreement.
7. Block promotion until all unexplained regressions are resolved.
8. Save the corpus, versions, hashes and comparison report.

## Promotion rule
Candidate may replace reference only when required correctness gates pass and the claimed improvement is measured.

# Content-Addressed Evidence Store

## Purpose
Store captured evidence as immutable, integrity-checkable artifacts whose identity is derived from source identity plus exact content hash.

## When to use
Use whenever external or internal source material becomes evidence for a claim, skill, validation result, benchmark or decision.

## Procedure
1. Capture exact source bytes before interpretation where technically and legally appropriate.
2. Compute SHA-256 of the captured bytes.
3. Build an evidence identity envelope from source, source version/attestation, media type and content hash.
4. Hash the envelope to obtain stable evidence ID.
5. Persist bytes and metadata atomically under the evidence ID.
6. If the same evidence ID already exists, verify compatibility and reuse it rather than rewriting it.
7. On read, recompute the content hash and fail if integrity differs from metadata.
8. Reference evidence ID from claims, research jobs, skills and outcomes rather than copying mutable source text into every artifact.

## Atomic nucleus
Evidence bytes used to justify a claim must remain bound to an immutable identity and verifiable content hash.

## Acceleration rule
Content addressing permits safe deduplication and cache reuse. It must never skip source/version compatibility checks merely because body bytes happen to match.

## Quality gates
- Tampering is detected on read.
- Repeated identical capture is idempotent.
- Writes are atomic and safe for portable local storage.
- Raw evidence is kept separate from interpretations and claims.

# Speed Without Accuracy Loss

## Purpose
Accelerate OCULUS work only when the accelerated path preserves correctness, evidence completeness, provenance, reproducibility and rollback.

## Use when
Any optimization proposes caching, batching, parallelism, skipping work, precomputation or incremental reuse.

## Inputs
- reference slow path;
- candidate fast path;
- representative corpus;
- correctness oracle;
- latency/cost metrics.

## Procedure
1. Freeze a representative reference corpus and input hashes.
2. Execute the slow/reference path and persist outputs plus provenance.
3. Execute the candidate accelerated path on the same inputs.
4. Compare semantic outputs, evidence refs, provenance edges and validation decisions.
5. Measure wall time, CPU/network cost and cache hit/miss behavior.
6. Reject the optimization if any required evidence/provenance disappears.
7. Reject the optimization if disagreement exceeds the explicitly allowed tolerance.
8. Keep a runtime switch to fall back to the reference path.
9. Record benchmark and equivalence evidence.

## Quality gates
- no silent evidence loss;
- no provenance loss;
- no irreversible merge based only on fast-path similarity;
- deterministic replay where applicable;
- reference fallback available;
- measurable speed-up.

## Output
A decision: `PROMOTE_FAST_PATH`, `KEEP_EXPERIMENTAL`, or `REJECT`, with benchmark and equivalence evidence.

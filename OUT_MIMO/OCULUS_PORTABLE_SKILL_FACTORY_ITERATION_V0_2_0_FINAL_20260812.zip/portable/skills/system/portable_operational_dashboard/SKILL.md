# Portable Operational Dashboard

## Purpose
Design a dense desktop dashboard for a portable local application so the user can understand system state, execute core workflows and inspect provenance without turning the UI into a decorative landing page or adding fragile external dependencies.

## When to use
Use when building or revising a local-first dashboard, control tower, agent console, research workstation or portable desktop web UI.

## Atomic decomposition

### Substance
Human control and observability of the local system.

### Molecules
- navigation;
- runtime status;
- primary workflow;
- operational metrics;
- task/forms;
- registries/tables;
- evidence/provenance views;
- external-agent status;
- quality/battlecheck status;
- errors and recovery.

### Atoms
1. One persistent navigation model.
2. One visible runtime/connection state.
3. Domain-specific top metrics, not vanity counters.
4. The primary pipeline visible on the overview screen.
5. Progressive disclosure: overview first, detailed operations in dedicated views.
6. Native operational controls wired to real local API endpoints.
7. Search/filter for large registries.
8. Compact status tags and timestamps.
9. Explicit empty/error/loading states.
10. Responsive fallback for narrower windows.
11. Keyboard-reachable native controls.
12. No required CDN, webfont, analytics or external JS for core operation.

## Atomic nucleus
The dashboard must remain useful when completely offline except for the application's own localhost API. It must show real system state and expose real operations; visual polish may never hide failures, missing evidence or incomplete pipeline stages.

## Visual language
- dark low-glare desktop surface;
- restrained accent colors assigned semantically;
- compact sidebar + top status bar;
- small radius, thin borders, high information density;
- strong typographic hierarchy instead of oversized marketing headings;
- charts only when they communicate an actual operational metric;
- monospace only for hashes, IDs and machine traces.

## Acceleration rule
Keep the core dashboard self-contained as one static bundle where practical. Prefer browser-native HTML/CSS/JS and the local API over framework/runtime dependencies until complexity proves the need for them. This reduces packaging, startup and update costs without reducing information fidelity.

## Quality gates
- core UI works without Internet/CDN access;
- every displayed live metric is derived from a real API or clearly marked static/planned;
- failure states remain visible;
- no navigation view destroys unsaved local input unexpectedly;
- registry and trace views remain usable with large datasets through filtering/pagination/virtualization as scale grows;
- responsive layout does not remove critical controls;
- the dashboard is not considered complete until its primary workflow can be executed end to end from the UI.

# Deterministic Task Fingerprint

## Purpose
Give semantically equivalent normalized task intake requests the same stable identity so repeated work can be deduplicated, cached and replayed without silently changing meaning.

## When to use
Use at task intake before research, skill resolution, scheduling, caching or result reuse.

## Procedure
1. Parse the request into typed fields rather than hashing raw prose.
2. Normalize controlled tokens such as platform, language, content type, goal and surfaces.
3. Normalize unordered sets by deduplicating and sorting them.
4. Normalize fields whose task semantics are explicitly case-insensitive using case folding plus whitespace normalization. Do not apply this blindly to arbitrary case-sensitive payloads.
5. Normalize free-text query lists conservatively: trim/collapse whitespace, apply only the domain-approved case policy, deduplicate and sort; do not paraphrase through an LLM.
6. Serialize the normalized typed task deterministically.
7. Compute SHA-256 of the normalized representation.
8. Use the fingerprint for idempotency, cache lookup and replay trace.
9. Preserve the original request separately when auditability requires it.

## Atomic nucleus
Equivalent normalized task semantics must produce the same fingerprint; materially different task semantics must not be intentionally collapsed.

## Acceleration rule
Fingerprint lookup is a deterministic fast path. It may skip repeated downstream work only when the reused artifact is bound to compatible task-schema, skill, evidence and config versions.

## Quality gates
- Same normalized input is stable across repeated runs.
- Ordering of set-like fields does not change identity.
- Domain-approved case-only differences do not create duplicate tasks.
- Fingerprint never substitutes for provenance or version compatibility checks.
- No fuzzy semantic merge occurs at this layer.
- Regression tests must include normalization pairs that previously produced different fingerprints.

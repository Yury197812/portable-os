# Controlled Outbound Internet

## Purpose
Provide useful Internet access while preserving explicit policy, bounded resource use and provenance.

## Procedure
1. Accept only HTTP/HTTPS URLs.
2. Resolve access through explicit allowed-host/provider policy.
3. Apply timeouts, response-size bounds and concurrency budgets.
4. Record request target, final URL, status, truncation and error class.
5. Preserve source identity/hash when promoted into evidence.
6. Enforce platform terms/robots/legal basis in the higher-level source adapter.
7. Fail closed when policy is absent or ambiguous.

## Quality gates
- no arbitrary scheme execution;
- no unbounded fetch;
- no silent host bypass;
- provenance event for research-relevant requests;
- provider-specific policy before large-scale collection.

# Incremental Diff Processing

## Purpose
Recompute only what changed while preserving the same result as a full rebuild.

## Use when
Sources, skills, book chapters, evidence or code have stable hashes and only a subset changed.

## Procedure
1. Compute stable hashes for all inputs.
2. Build the dependency impact set from changed inputs.
3. Reuse outputs only when producer version, policy version and dependencies are unchanged.
4. Recompute the impacted closure.
5. Periodically run a full rebuild as an oracle.
6. Diff incremental and full outputs.
7. Invalidate caches when any dependency/provenance uncertainty exists.

## Quality gates
- no stale output outside the computed impact set;
- full-build equivalence on scheduled oracle runs;
- versioned invalidation policy;
- trace showing reused versus recomputed artifacts.

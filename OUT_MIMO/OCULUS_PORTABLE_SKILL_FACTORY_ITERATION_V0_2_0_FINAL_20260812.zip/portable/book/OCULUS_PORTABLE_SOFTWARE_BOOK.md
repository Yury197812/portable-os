# OCULUS PORTABLE SKILL FACTORY — КНИГА РАЗРАБОТКИ

Версия книги: **0.2.0**  
Статус: **живой канон, второй полный OCULUS-цикл**  
Продукт: **OCULUS Portable Skill Factory**  
Целевой первый хост: **Windows x64, portable folder**

> Эта книга не является журналом коммитов. Каждый полный проход начинается заново с Главы 1, раскладывает продукт на вещество → молекулы → атомы → атомное ядро, проверяет старые решения, пишет и тестирует ПО, извлекает повторно используемые скиллы, дедуплицирует и пересобирает их, затем применяет полученные скиллы к следующей части того же прохода.

---

# Глава 1. Зачем существует продукт

Цель — создать переносимое локальное ПО, которое запускается на Windows из обычной папки без обязательной классической установки и превращает OCULUS Platform Skill Factory в исполняемую рабочую систему.

Продукт должен объединить в одном локальном контуре:

- постановку и нормализацию задач;
- поиск существующих skills прежде создания новых;
- controlled Internet access;
- исследовательские jobs;
- неизменяемое evidence;
- provenance;
- claim/conflict graph;
- `REUSE → EXTEND → MERGE → CREATE_NEW`;
- Validator и adversarial battlecheck;
- применение skills к реальным задачам;
- outcome feedback;
- локальный dashboard;
- API;
- MIMO как внешний, но не блокирующий исследовательский агент;
- живую книгу развития самого продукта;
- автоматическое извлечение reusable skills из каждой итерации.

Программа не должна быть «генератором промптов». Она должна быть **исполняемым контуром исследования, доказательства, компиляции, применения и переоценки навыков**.

## 1.1 Главный инвариант

> **Быстрее можно только тогда, когда доказано, что ускорение не уменьшает точность, evidence completeness, provenance, воспроизводимость, проверяемость и rollbackability.**

Это атомное ядро всей архитектуры. Если оно нарушено, ускорение считается дефектом даже при большом выигрыше времени.

## 1.2 Что изменилось после повторного чтения Главы 1

В первом цикле продукт был описан преимущественно слоями. Во втором цикле этого недостаточно: слой может выглядеть правильным, но содержать неявные семантические дефекты. Поэтому добавлена обязательная атомарная декомпозиция каждого существенного узла.

---

# Глава 2. OCULUS-цикл разработки

Цикл продукта:

`TASK → NORMALIZE → RESOLVE → GAP → RESEARCH → EVIDENCE → CLAIMS → CONFLICTS → DEDUP → COMPILE → VALIDATE → BATTLECHECK → APPLY → OUTCOME → REVALIDATE`

Цикл разработки самого ПО:

`CHAPTER_1_RECHECK → MIMO_CHECK → INVENTORY → ATOMIZE → INVARIANTS → SKILL_RESOLVE → IMPLEMENT → TEST → ADVERSARIAL_CHECK → BOOK_REBUILD → SKILL_EXTRACTION → SKILL_DEDUP → SKILL_REBUILD → APPLY_SKILLS → RELEASE_ZIP`

MIMO проверяется в начале каждой итерации, но **никогда не блокирует цикл**. На входе текущей итерации в `MIMO/inbox/` не было нового batch, а в coordination issue не было ответа; разработка продолжилась немедленно.

Состояния знаний не смешиваются:

- `FACT` — подтверждённое наблюдение/состояние;
- `INFERENCE` — вывод из фактов;
- `HYPOTHESIS` — непроверенное предположение;
- `EXPERIMENT` — проверяемое изменение;
- `DECISION` — принятое архитектурное решение.

---

# Глава 3. Метод «вещество → молекулы → атомы → атомное ядро»

## 3.1 Вещество

Вещество — крупная область продукта, которую пользователь воспринимает как цель: research, skills, evidence, Internet, dashboard, release.

## 3.2 Молекула

Молекула — автономная подсистема с собственным контрактом и тестами. Например, `Skill Resolver`, `Evidence Store`, `MIMO Inbox Scanner`.

## 3.3 Атом

Атом — минимальная техническая ответственность, которую можно проверить отдельно: нормализация поля, вычисление SHA-256, запрет redirect на неразрешённый host, точный `REUSE` по ID.

## 3.4 Атомное ядро

Атомное ядро — минимальный инвариант, без которого атом формально работает, но семантически неверен.

Примеры:

- у Task Fingerprint ядро — эквивалентные нормализованные задачи имеют одинаковый fingerprint;
- у Evidence Store ядро — используемые для доказательства байты связаны с проверяемым immutable identity;
- у Resolver ядро — новый skill нельзя создавать до проверки reuse/extend;
- у acceleration ядро — fast candidate не получает production status при расхождении с reference;
- у MIMO ядро — внешний результат не становится каноном автоматически и отсутствие результата не блокирует работу.

## 3.5 Почему это ускоряет, а не тормозит

Правильная атомизация даёт безопасный параллелизм. Независимые молекулы можно разрабатывать и тестировать одновременно. Связанные атомы сохраняют упорядоченный путь, пока их общий инвариант не доказан.

---

# Глава 4. Вещества продукта

Текущий продукт разложен на десять веществ:

1. **Task Substance** — входная задача и её идентичность.
2. **Skill Substance** — поиск, разрешение, компиляция и lifecycle skills.
3. **Research Substance** — сбор источников и эксперименты.
4. **Evidence Substance** — immutable snapshots и provenance.
5. **Network Substance** — controlled outbound Internet.
6. **State Substance** — локальный trace и восстановление.
7. **Quality Substance** — tests, Validator, battlecheck, equivalence gates.
8. **MIMO Substance** — внешний research intake.
9. **Human Interface Substance** — dashboard/API.
10. **Release Substance** — portable build, manifest, ZIP, rollback.

Каждое вещество может развиваться независимо только до границы общих инвариантов.

---

# Глава 5. Молекулы и атомы текущей версии

## 5.1 Task Intake molecule

Атомы:

- typed fields;
- conservative normalization;
- sorting set-like fields;
- duplicate removal;
- deterministic JSON representation;
- SHA-256 fingerprint;
- stable task ID;
- validation required fields.

Реализовано в `internal/tasks/`.

## 5.2 Skill Resolver molecule

Атомы:

- exact ID lookup;
- exact normalized-name lookup;
- deterministic token candidate prefilter;
- bounded candidate list;
- reproducible ordering;
- ambiguity detection;
- explicit decision;
- `AutoMerge=false` в deterministic layer.

Реализовано в `internal/skills/resolver.go`.

## 5.3 Evidence Store molecule

Атомы:

- raw content SHA-256;
- source/version/media type envelope;
- evidence ID SHA-256;
- atomic write;
- immutable reuse;
- metadata/content separation;
- tamper check on read.

Реализовано в `internal/evidence/`.

## 5.4 MIMO Inbox molecule

Атомы:

- cheap directory scan;
- deterministic sorted file inventory;
- SHA-256 каждого файла;
- deterministic batch fingerprint;
- empty inbox = valid non-blocking state.

Реализовано в `internal/mimo/`.

## 5.5 Accuracy Equivalence molecule

Атомы:

- slow/reference runner;
- fast/candidate runner;
- independent timing;
- canonical JSON semantic comparison;
- key-order independence;
- explicit `Equivalent` result;
- computed speedup that не заменяет correctness.

Реализовано в `internal/quality/`.

---

# Глава 6. Portable-first архитектура

Первый целевой хост — Windows x64.

Базовый portable contract:

- одна переносимая папка;
- `oculus-portable.exe`;
- локальные `config/`, `data/`, `skills/`, `dashboard/`, `MIMO/`;
- отсутствие обязательной внешней БД;
- отсутствие обязательного installer;
- отсутствие критической зависимости от Windows Registry;
- относительные пути;
- возможность копирования всей папки на другой ПК;
- локальный HTTP server по умолчанию на `127.0.0.1`;
- controlled outbound Internet;
- воспроизводимый build;
- release ZIP как целостный переносимый артефакт.

Для runtime используется Go. Во втором цикле решение оставлено, потому что уже доказаны полезные свойства для текущего vertical slice: единый native binary, стандартный HTTP, concurrency primitives и простой Windows cross-build. Это `DECISION`, а не вечный догмат.

---

# Глава 7. Task Intake и детерминированная идентичность

Сырая формулировка пользователя не должна становиться cache key напрямую.

Task Input v0.2 включает:

- platform;
- surfaces;
- niche;
- geo;
- language;
- content type;
- goal;
- target queries.

Нормализация deliberately conservative: она исправляет регистр, пробелы, порядок множеств и дубли, но не перефразирует смысл через LLM.

Преимущество — безопасный fast path:

`raw task → typed normalize → fingerprint → duplicate/cache/replay lookup`

LLM не нужен для определения того, что две структурно одинаковые задачи отличаются только регистром или порядком surfaces.

---

# Глава 8. Resolve прежде Research

Новый skill — дорогой и потенциально дублирующий артефакт. Поэтому разрешение существующих capability всегда раньше research.

Resolver v1 использует дешёвый deterministic слой:

1. exact ID;
2. normalized name;
3. token overlap;
4. bounded ranking;
5. ambiguity flag.

Решения:

- `REUSE` — точное совпадение;
- `EXTEND` — сильный кандидат, но требуется исследование gap;
- `CREATE_NEW` — нет достаточного кандидата;
- будущий `MERGE_CANDIDATE` — только как предложение глубокой проверке.

Критическое правило: deterministic resolver **не имеет права автоматически merge** два неоднозначных skills.

Следующий слой позже добавит metadata, embeddings и structural comparison, но deterministic prefilter останется первой ступенью ради скорости.

---

# Глава 9. Evidence как неизменяемый фундамент

Первый `events.jsonl` давал trace, но не обеспечивал полноценное immutable evidence.

Во втором цикле появился content-addressed Evidence Store.

Identity строится из:

`source + source_version + media_type + SHA256(exact bytes)`

После чего envelope также получает SHA-256 evidence ID.

Это позволяет:

- дедуплицировать одинаковые captures;
- связывать claims с конкретным snapshot;
- обнаруживать tampering;
- безопасно строить evidence-bound cache;
- не копировать один и тот же источник по всем artifacts.

`CapturedAt` не входит в identity, иначе повторный capture одинакового snapshot создавал бы бессмысленный новый ID.

---

# Глава 10. Controlled Internet как capability, а не «доступ в сеть»

Internet Gateway продолжает работать fail-closed.

Текущие ограничения:

- HTTP/HTTPS only;
- explicit host allowlist;
- redirect повторно проходит allowlist check;
- bounded concurrency;
- timeout;
- max response bytes;
- explicit User-Agent;
- success/failure trace.

В предыдущем проходе adversarial review выявил важную дыру: исходный allowlisted URL мог redirect на запрещённый host. Ошибка исправлена через `CheckRedirect` и отдельный тест. Этот пример подтверждает необходимость атомизации: проверка начального URL и проверка каждого фактического сетевого hop — разные атомы.

Следующие атомы:

- provider adapters;
- per-provider rate budgets;
- retry + jitter;
- robots/terms policy;
- source attestation;
- conditional requests;
- circuit breaker;
- fetch → evidence binding.

---

# Глава 11. MIMO — параллельный, но не блокирующий агент

MIMO остаётся внешним research source.

Контур:

- `MIMO/requests/` — задания OCULUS;
- `MIMO/inbox/` — raw batches MIMO;
- `MIMO/processed/` — обработанные batches;
- `MIMO/quarantine/` — спорные/невалидные материалы;
- GitHub issue — короткая координация.

Каждый batch проходит:

`INTAKE → INVENTORY → CLAIMS → PROVENANCE → CONFLICT → DEDUP → VALIDATION → BATTLECHECK → DISPOSITION → PROMOTION`

Новое правило второго цикла:

> MIMO проверяется на каждой итерации, но отсутствие новых материалов приводит к `NO_NEW_MIMO` и немедленному продолжению основной разработки.

Чтобы это было не только текстовым правилом, в ПО реализован deterministic `MIMO Inbox Scanner`, который вычисляет batch fingerprint без дорогого семантического анализа.

---

# Глава 12. Ускорение без потери точности

Ускорение рассматривается как first-class architecture.

Разрешённые ускорители:

- deterministic fast paths;
- bounded parallelism;
- batching;
- incremental diff;
- content-addressed reuse;
- evidence-bound caching;
- precomputed indexes;
- compiled routing;
- параллельный сбор независимых sources.

Но каждый ускоритель проходит модель:

`SLOW_REFERENCE → FAST_CANDIDATE → EQUIVALENCE → PERFORMANCE DELTA → PROMOTE/REJECT`

Во втором цикле добавлен исполняемый JSON equivalence primitive. Он сравнивает семантически декодированный JSON, поэтому перестановка ключей не считается ошибкой, а изменение значения — считается.

Это пока только один comparator. Для rank lists, claims, graphs и generated content потребуются типизированные equivalence contracts.

---

# Глава 13. Локальное состояние и provenance

`data/events.jsonl` остаётся append-only runtime trace.

Текущие события уже включают:

- `task.created`;
- `skills.resolve`;
- `evidence.captured`;
- `internet.fetch.ok`;
- `internet.fetch.failed`.

Целевой Event Envelope должен дополнительно иметь:

- actor;
- operation version;
- input hash;
- output hash;
- evidence refs;
- skill bundle/version;
- config snapshot;
- latency;
- error class;
- parent event / trace ID.

JSONL остаётся bootstrap storage, но дальнейшая архитектура должна получить transaction/snapshot/migration semantics без потери portable свойства.

---

# Глава 14. API и Dashboard

API v0.2:

- `GET /api/v1/health`;
- `GET /api/v1/skills`;
- `POST /api/v1/skills/resolve`;
- `POST /api/v1/tasks`;
- `POST /api/v1/evidence`;
- `GET /api/v1/evidence/{id}`;
- `GET /api/v1/mimo/inbox`;
- `POST /api/v1/fetch`;
- `GET /api/v1/events`.

Dashboard теперь показывает и позволяет использовать:

- runtime/version;
- количество skills;
- MIMO inbox;
- Task Intake;
- Resolve Before Research;
- Immutable Evidence capture;
- Controlled Internet;
- Skill Registry.

То есть UI уже отражает продуктовый pipeline, а не только health-check.

---

# Глава 15. Quality Gates

Минимальные gates текущего этапа:

- `gofmt`;
- `go vet`;
- `go test -race ./...`;
- Linux smoke build;
- Windows x64 portable build;
- task fingerprint normalization tests;
- exact skill reuse test;
- no-auto-merge invariant;
- evidence deterministic identity;
- evidence tamper detection;
- MIMO stable batch fingerprint;
- missing MIMO inbox = empty/non-blocking;
- JSON equivalence positive test;
- accuracy regression negative test;
- Internet host allowlist tests;
- Internet redirect policy test;
- API integration tests.

Компиляция сама по себе не является quality gate достаточного уровня.

---

# Глава 16. Реализованный вертикальный срез v0.2.0

После повторного прохода с Главы 1 система содержит:

1. Go native runtime.
2. Portable-relative config.
3. Local API server.
4. Operational dashboard.
5. Filesystem Skill Registry + SHA-256.
6. Deterministic Task Intake + fingerprint.
7. Resolve-first Skill Resolver v1.
8. Immutable content-addressed Evidence Store.
9. Controlled Internet with redirect enforcement.
10. Deterministic non-blocking MIMO Inbox Scanner.
11. Append-only event trace.
12. Reference-vs-candidate JSON equivalence primitive.
13. Windows cross-build.
14. CI quality pipeline.
15. Living book.
16. Reusable `SKILL.md` corpus.

Это всё ещё не полный production Skill Factory: research jobs, claim graph, conflict graph, skill compiler, promotion state machine, outcomes и real platform adapters ещё впереди.

---

# Глава 17. Battlecheck текущего цикла

Во втором цикле были проверены следующие классы ошибок.

## 17.1 Дублирование skills

Результат: новые правила сравнивались с текущим registry. Не создан отдельный skill «MIMO не ждать»: вместо этого расширен существующий `mimo_intake_validation`.

## 17.2 Cache-key over-normalization

Риск: агрессивная LLM-нормализация могла бы объединить разные задачи.

Решение: Task Fingerprint использует только conservative deterministic normalization.

## 17.3 Evidence identity drift

Риск: timestamp в identity делал бы одинаковое evidence всегда новым.

Решение: `CapturedAt` не входит в evidence identity.

## 17.4 Evidence tampering

Риск: metadata остаётся прежней после изменения content file.

Решение: content hash перепроверяется при чтении; есть negative test.

## 17.5 Resolver destructive merge

Риск: similarity threshold мог автоматически слить skills.

Решение: deterministic resolver всегда `AutoMerge=false`.

## 17.6 Fast path correctness

Риск: ускоренный path возвращает другое значение, но выигрывает benchmark.

Решение: speedup не даёт promotion без equivalence.

## 17.7 External-agent latency

Риск: разработка ждёт MIMO.

Решение: empty inbox — штатный non-blocking результат.

## 17.8 Незакрытые риски

Остаются для следующего прохода:

- concurrent Evidence Put пока сериализован глобальным mutex: корректно, но потенциально узко;
- resolver v1 знает мало metadata и может дать слабый candidate score;
- task fingerprint пока не versioned schema fingerprint;
- JSON equivalence недостаточен для domain-specific outputs;
- evidence capture API пока принимает whole body в памяти;
- research job lifecycle отсутствует;
- source terms/robots policy ещё не встроена;
- Windows clean-machine smoke пока не автоматизирован отдельным runner.

---

# Глава 18. Извлечение, дедупликация, пересборка и применение скиллов

Скилл считается полезным только если он переносится на следующие задачи.

## 18.1 Извлечено в этом цикле

Созданы новые reusable skills:

- `atomic_decomposition_before_implementation`;
- `deterministic_task_fingerprint`;
- `resolve_before_research`;
- `content_addressed_evidence_store`.

## 18.2 Расширено вместо дублирования

`mimo_intake_validation` расширен правилом non-blocking iteration. Отдельный почти одинаковый skill не создавался.

## 18.3 Повторно применены существующие skills

- `chapter_one_architecture_recheck` — заставил начать проход с цели, а не с очередного файла;
- `speed_without_accuracy_loss` — определил допустимость ускорений;
- `deterministic_fast_path` — применён к Task Fingerprint, Resolver и MIMO check;
- `bounded_parallelism` — сохраняется как policy для Internet и будущего research scheduler;
- `incremental_diff_processing` — новые подсистемы добавлялись без пересборки неизменённых частей runtime;
- `evidence_complete_cache` — повлиял на identity Evidence Store и будущие cache contracts;
- `reference_vs_candidate_equivalence_gate` — превратился в исполняемый `internal/quality` primitive;
- `portable_runtime_integrity` — сохранил относительные пути и Windows build;
- `controlled_outbound_internet` — применён к redirect battlecheck;
- `mimo_intake_validation` — применён в начале текущей итерации.

## 18.4 Новый принцип Skill Factory

`BOOK CLAIM → ATOM → REPEATED CAPABILITY → DEDUP → SKILL.md → TEST/USE → NEXT ITERATION`

То есть книга производит skills, а skills возвращаются в книгу и код как активные методы работы.

---

# Глава 19. Следующий полный OCULUS-проход

Следующий проход снова начинается с Главы 1 и повторно проверяет, соответствует ли реализация исходной цели.

Приоритетные молекулы:

1. versioned Task Schema + idempotency store;
2. evidence-bound cache;
3. fetch → evidence atomic pipeline;
4. Research Job lifecycle/state machine;
5. Source Registry;
6. Claim Miner contract;
7. Provenance Graph;
8. Conflict Graph;
9. Resolver metadata index + semantic fallback;
10. skill compiler + lifecycle;
11. typed equivalence comparators;
12. benchmark runner с repeated samples/spread;
13. MIMO processed/quarantine disposition writer;
14. Windows clean-machine smoke artifact;
15. reproducible release manifest + final ZIP.

Ускорение следует искать прежде всего через deterministic/indexed/incremental paths, а не через уменьшение количества проверок.

---

# Глава 20. Актуальный список скиллов

Эта глава всегда остаётся последней нумерованной главой книги.

## OCULUS / architecture / acceleration

1. `atomic_decomposition_before_implementation`
2. `chapter_one_architecture_recheck`
3. `speed_without_accuracy_loss`
4. `deterministic_fast_path`
5. `bounded_parallelism`
6. `incremental_diff_processing`
7. `reference_vs_candidate_equivalence_gate`
8. `portable_runtime_integrity`
9. `controlled_outbound_internet`

## Task / resolver / evidence

10. `deterministic_task_fingerprint`
11. `resolve_before_research`
12. `content_addressed_evidence_store`
13. `evidence_complete_cache`

## External-agent intake

14. `mimo_intake_validation`

Всего в текущем portable runtime corpus: **14 system skills**.

Правило списка: skill входит сюда только если существует как реальный `SKILL.md` в registry. Следующая итерация обязана сначала попытаться `REUSE/EXTEND/MERGE` эти skills и лишь затем создавать новые.

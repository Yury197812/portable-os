# OCULUS PORTABLE SKILL FACTORY — КНИГА РАЗРАБОТКИ v0.2.0 FULL

Статус: **живой канон текущей итерации**  
Продукт: **OCULUS Portable Skill Factory**  
Целевой первый хост: **Windows x64 / portable folder**

> Книга создаётся одновременно с программой. Каждый полный цикл возвращается к Главе 1, раскладывает проект на вещество → молекулы → атомы → атомное ядро, проверяет инварианты, пишет код, извлекает повторно используемые скиллы, дедуплицирует и пересобирает их, после чего применяет эти же скиллы к следующему проходу.

---

# Глава 1. Цель продукта

Нужно создать переносимое локальное ПО, которое запускается из обычной папки и превращает фабрику платформенных навыков в исполняемую систему.

Система должна уметь:

- принимать и нормализовать задачи;
- сначала искать существующие skills;
- выходить в интернет через управляемые adapters;
- собирать immutable evidence;
- строить provenance;
- отделять FACT / INFERENCE / HYPOTHESIS / EXPERIMENT / DECISION;
- обнаруживать конфликты;
- выбирать `REUSE → EXTEND → MERGE → CREATE_NEW`;
- валидировать и battlecheck-ить новые знания;
- применять skills к реальным задачам;
- получать outcomes;
- переоценивать навыки по фактическим результатам;
- работать через локальный dashboard и API;
- принимать MIMO как внешний research-source, не отдавая ему право автоматически менять канон;
- развивать собственную книгу и Skill Registry в каждом проходе.

## Атомное ядро продукта

**Скорость не имеет права покупать результат ценой точности.**

Любой fast path должен сохранять:

- семантику результата;
- evidence completeness;
- provenance;
- воспроизводимость;
- validation depth;
- rollbackability.

Если это не доказано — ускорение не является production optimization.

---

# Глава 2. Канонический OCULUS-loop

Рабочая петля:

`CHAPTER_1_RECHECK → MIMO_CHECK → INVENTORY → ATOMIZE → INVARIANTS → SKILL_RESOLVE → IMPLEMENT → TEST → BATTLECHECK → BOOK_REBUILD → SKILL_EXTRACTION → SKILL_DEDUP → SKILL_REBUILD → APPLY_SKILLS → RELEASE_ZIP`

Петля продукта:

`TASK → NORMALIZE → RESOLVE → GAP → RESEARCH → EVIDENCE → CLAIMS → CONFLICTS → DEDUP → COMPILE → VALIDATE → BATTLECHECK → APPLY → OUTCOME → REVALIDATE`

Отдельная схема хранится в `book/OCULUS_LOOP.md`.

MIMO проверяется на каждой итерации. Если новых данных нет, фиксируется `NO_NEW_MIMO`, и основной цикл продолжается немедленно.

---

# Глава 3. Вещество, молекулы, атомы и атомное ядро

## Вещество

Крупная пользовательская или архитектурная область: Task, Skills, Evidence, Network, Quality, Dashboard, Release.

## Молекула

Автономная подсистема с контрактом: Task Intake, Resolver, Evidence Store, MIMO Scanner, Internet Gateway.

## Атом

Минимальная ответственность, которую можно проверить отдельно: нормализация одного поля, вычисление хеша, проверка redirect-host, exact skill lookup.

## Атомное ядро

Инвариант, без которого атом может «работать», но давать неправильный смысл.

Примеры:

- Task: эквивалентные нормализованные задачи имеют одинаковую identity;
- Resolver: новый skill нельзя создавать до проверки reuse;
- Evidence: доказательные байты нельзя отделить от их immutable identity;
- MIMO: внешний batch не становится каноном автоматически и не блокирует отсутствие ответа;
- Dashboard: отображает реальное состояние и реальные операции, а не декоративные цифры;
- Acceleration: fast candidate не проходит promotion при quality regression.

---

# Глава 4. Карта веществ продукта

Текущая система делится на:

1. Task Substance.
2. Skill Substance.
3. Research Substance.
4. Evidence Substance.
5. Network Substance.
6. State/Provenance Substance.
7. Quality Substance.
8. MIMO Substance.
9. Human Interface Substance.
10. Release Substance.

Независимые молекулы разрешено разрабатывать параллельно. Связанные атомы сохраняют последовательный owner/path до доказательства общих инвариантов.

---

# Глава 5. Portable-first runtime

Контракт первой платформы:

- Windows x64;
- один `oculus-portable.exe`;
- переносимая папка;
- относительные пути;
- `config/`, `data/`, `skills/`, `dashboard/`, `MIMO/`, `book/`, `api/` рядом с runtime;
- отсутствие обязательной внешней БД;
- отсутствие обязательного installer;
- отсутствие критической зависимости от Windows Registry;
- localhost API на `127.0.0.1` по умолчанию;
- controlled outbound Internet;
- folder-level rollback;
- versioned ZIP каждого завершённого прохода.

Для runtime оставлен Go: текущий vertical slice уже доказывает native single-binary build, cross-build на Windows, стандартный HTTP и дешёвые concurrency primitives.

Это `DECISION`, а не вечный FACT.

---

# Глава 6. Task Intake

Реализованный `internal/tasks/` принимает:

- platform;
- surfaces;
- niche;
- geo;
- language;
- content_type;
- goal;
- target_queries.

После conservative normalization строится SHA-256 fingerprint.

Первый CI-cycle обнаружил реальный дефект: dedup query использовал case-insensitive key, но сохранял исходный регистр первого элемента. Из-за этого две эквивалентные задачи могли получить разные fingerprints.

Ошибка была разложена до атома:

`dedup_key != stored_canonical_value`.

После исправления case-insensitive поля используют единое canonical representation.

Это пример того, как тест изменил не только код, но и skill `deterministic_task_fingerprint`.

---

# Глава 7. Resolve Before Research

Новый skill — дорогой и рискованный артефакт. Поэтому research не должен начинаться до проверки существующих skills.

Resolver v1:

1. exact ID;
2. normalized name;
3. token overlap;
4. bounded candidates;
5. deterministic ordering;
6. ambiguity flag;
7. `AutoMerge=false`.

Решения:

- `REUSE`;
- `EXTEND`;
- будущий `MERGE_CANDIDATE`;
- `CREATE_NEW`.

Следующая версия добавит metadata index, structural comparison и semantic fallback, но дешёвый deterministic prefilter останется первой ступенью.

---

# Глава 8. Evidence Store

`internal/evidence/` реализует content-addressed immutable storage.

Identity:

`SHA256(source + source_version + media_type + SHA256(exact_bytes))`.

Инварианты:

- одинаковый snapshot имеет одинаковый evidence ID;
- timestamp не входит в identity;
- raw bytes и metadata разделены;
- запись атомарна;
- content hash перепроверяется при чтении;
- tampering приводит к ошибке;
- interpretation не переписывает raw evidence.

Это основа будущих Claim Graph, Conflict Graph и evidence-bound cache.

---

# Глава 9. Controlled Internet

Интернет не является «свободной сетью». Это capability с политиками.

Текущий gateway:

- HTTP/HTTPS only;
- explicit allowlist;
- empty allowlist = deny all;
- redirect host проверяется повторно;
- bounded concurrency;
- timeout;
- max response bytes;
- User-Agent;
- event trace.

Предыдущий battlecheck выявил redirect bypass: разрешённый URL мог перевести запрос на запрещённый host. Отдельный `CheckRedirect` atom закрыл этот класс ошибки.

Следующие молекулы:

- source adapters;
- terms/robots policy;
- retry+jitter;
- rate budgets;
- conditional requests;
- source attestation;
- circuit breaker;
- fetch→evidence atomic pipeline.

---

# Глава 10. MIMO

MIMO — внешний ускоритель research, но не authority канона.

Зоны:

- `MIMO/requests/`;
- `MIMO/inbox/`;
- `MIMO/processed/`;
- `MIMO/quarantine/`;
- GitHub issue для короткой координации.

Batch pipeline:

`INTAKE → INVENTORY → CLAIMS → PROVENANCE → CONFLICT → DEDUP → VALIDATION → BATTLECHECK → DISPOSITION → PROMOTION`.

Во втором цикле реализован deterministic MIMO Inbox Scanner:

- сортирует файлы;
- хеширует каждый файл;
- строит batch fingerprint;
- делает повторное сканирование idempotent;
- пустой inbox возвращает штатный non-blocking state.

---

# Глава 11. Quality и acceleration

Разрешённые ускорители:

- deterministic fast paths;
- bounded parallelism;
- batching;
- incremental diff;
- content-addressed reuse;
- precomputed indexes;
- evidence-bound cache;
- compiled routing.

Но каждый fast path проходит:

`SLOW_REFERENCE → FAST_CANDIDATE → EQUIVALENCE → PERFORMANCE DELTA → PROMOTE/REJECT`.

`internal/quality/` уже содержит JSON equivalence primitive:

- object key order не считается различием;
- изменение semantic value считается regression;
- speedup вычисляется отдельно от correctness.

Для ranking, graphs, claims и generated content нужны отдельные typed comparators.

---

# Глава 12. State и provenance

Bootstrap trace остаётся append-only `data/events.jsonl`.

Текущие события:

- `task.created`;
- `skills.resolve`;
- `evidence.captured`;
- `internet.fetch.ok`;
- `internet.fetch.failed`.

Целевой Event Envelope должен получить:

- actor;
- operation version;
- input/output hashes;
- evidence refs;
- skill bundle/version;
- config snapshot;
- parent trace;
- latency;
- error class.

---

# Глава 13. Dashboard как рабочая станция

Dashboard переработан из технической страницы в компактный dark operational command center.

Визуальный ориентир текущего цикла: плотный desktop analytics UI с постоянной левой навигацией, тонкой верхней status bar, компактными метриками, dark panels, restrained accent colors и высокой информационной плотностью.

## Вещество

Человек должен видеть состояние системы и выполнять основные операции без терминала.

## Молекулы

- sidebar navigation;
- runtime status;
- overview metrics;
- OCULUS pipeline;
- task workspace;
- skill registry/resolver;
- evidence vault;
- MIMO intake;
- Internet Gateway;
- Quality/Battlecheck;
- event feed.

## Атомы

- persistent navigation;
- visible core status;
- live API-derived metrics;
- explicit planned/static quality status;
- search по Skill Registry;
- real Task/Resolve/Evidence/Fetch controls;
- empty/loading/error states;
- responsive fallback;
- native keyboard-reachable controls;
- self-contained HTML/CSS/JS;
- no CDN/webfont/external JS dependency for core UI.

## Атомное ядро

Dashboard остаётся полезным без внешнего интернета и показывает реальное состояние localhost runtime. Красивый интерфейс не имеет права скрывать ошибки, отсутствие evidence или незавершённые стадии pipeline.

В результате появился reusable skill `portable_operational_dashboard`.

---

# Глава 14. API v0.2

Рабочие endpoints:

- `GET /api/v1/health`;
- `GET /api/v1/skills`;
- `POST /api/v1/skills/resolve`;
- `POST /api/v1/tasks`;
- `POST /api/v1/evidence`;
- `GET /api/v1/evidence/{id}`;
- `GET /api/v1/mimo/inbox`;
- `POST /api/v1/fetch`;
- `GET /api/v1/events`.

Dashboard использует эти же endpoints; отдельная скрытая UI-логика не создаёт вторую модель продукта.

---

# Глава 15. Тестовый контур

Текущие gates:

- gofmt;
- go vet;
- `go test -race ./...`;
- Linux smoke build;
- Windows x64 cross-build;
- task normalization pairs;
- exact skill reuse;
- no-auto-merge;
- evidence deterministic identity;
- evidence tamper detection;
- MIMO fingerprint stability;
- empty MIMO non-blocking state;
- JSON equivalence positive/negative cases;
- Internet allowlist;
- redirect policy;
- API integration tests.

Компиляция сама по себе не является достаточным доказательством качества.

---

# Глава 16. Battlecheck v0.2

Проверены следующие классы атак/ошибок:

1. перестановка surfaces;
2. case/whitespace drift task identity;
3. missing required task fields;
4. exact skill reuse;
5. ambiguous skill merge;
6. duplicate evidence capture;
7. evidence tampering;
8. missing/empty MIMO inbox;
9. repeated MIMO scan;
10. JSON key-order differences;
11. fast candidate semantic regression;
12. outbound redirect bypass.

Отдельный отчёт: `releases/v0.2.0/BATTLECHECK.md`.

Главный результат: система реально нашла regression в Task Fingerprint, исправила код и пересобрала соответствующий skill.

---

# Глава 17. Извлечение и применение скиллов

Скиллы в OCULUS не являются приложением к книге. Они возвращаются в тот же цикл как инструменты разработки.

Текущая формула:

`BOOK CLAIM → ATOM → EXISTING SKILL SEARCH → REUSE/EXTEND/MERGE/CREATE → CODE/PROCESS → TEST → FAILURE EVIDENCE → SKILL REBUILD → RE-APPLY`.

В текущем проходе:

- `mimo_intake_validation` расширен вместо создания дубля;
- `reference_vs_candidate_equivalence_gate` реализован как executable quality primitive;
- `deterministic_task_fingerprint` был пересобран после CI failure;
- `portable_runtime_integrity` расширен обязательным iteration ZIP handoff;
- `portable_operational_dashboard` извлечён из UI-разбора и применён к новой панели.

Матрица применения: `releases/v0.2.0/SKILL_APPLICATION_MATRIX.md`.

---

# Глава 18. Что уже является работающим vertical slice

Текущая программа содержит:

1. native Go runtime;
2. portable config;
3. localhost API;
4. dark operational dashboard;
5. Skill Registry + SHA-256;
6. deterministic Task Intake;
7. Resolve-first Skill Resolver v1;
8. immutable Evidence Store;
9. controlled Internet;
10. MIMO Inbox Scanner;
11. append-only event trace;
12. JSON equivalence gate;
13. Windows x64 cross-build;
14. CI pipeline;
15. full iteration artifact packaging;
16. living OCULUS book;
17. reusable real `SKILL.md` corpus.

Это ещё не production Skill Factory: research jobs, Source Registry, Claim Graph, Conflict Graph, Compiler, skill lifecycle и Outcomes остаются следующими слоями.

---

# Глава 19. Незакрытые риски

1. Task Schema ещё не versioned inside fingerprint envelope.
2. Evidence Store использует глобальную сериализацию writes; корректно, но может ограничивать throughput.
3. Evidence API буферизует body целиком.
4. Resolver v1 слишком shallow для большого registry.
5. JSON comparator не универсален.
6. Dashboard registry table пока без server-side pagination/virtualization.
7. Research Job lifecycle отсутствует.
8. Source policy layer отсутствует.
9. Clean-machine Windows runtime smoke ещё не доказан отдельным Windows runner.
10. Full release manifest по каждому файлу должен стать отдельным machine-verifiable artifact.

Эти риски не маскируются версией; они становятся входом следующей Главы 1.

---

# Глава 20. Следующий проход

Следующая итерация снова начинается с Главы 1.

Приоритет:

1. versioned Task Schema;
2. idempotency store;
3. fetch→evidence atomic pipeline;
4. evidence-bound cache;
5. Research Job state machine;
6. Source Registry;
7. Claim Miner contract;
8. Provenance Graph;
9. Conflict Graph;
10. Resolver metadata index + semantic fallback;
11. Skill Compiler + lifecycle;
12. typed equivalence comparators;
13. repeated benchmark distributions, а не single timing;
14. MIMO disposition writer;
15. Windows clean-machine smoke;
16. full release manifest and final ZIP verification.

Главный источник ускорения — **индексы, кеширование, incremental diff, bounded parallelism и deterministic fast paths**, а не сокращение доказательств и проверок.

---

# Глава 21. Актуальный полный список скиллов

Эта глава всегда остаётся последней нумерованной главой книги.

## Architecture / cycle

1. `atomic_decomposition_before_implementation`
2. `chapter_one_architecture_recheck`

## Acceleration / quality

3. `speed_without_accuracy_loss`
4. `deterministic_fast_path`
5. `bounded_parallelism`
6. `incremental_diff_processing`
7. `reference_vs_candidate_equivalence_gate`
8. `evidence_complete_cache`

## Portable / network / UI

9. `portable_runtime_integrity`
10. `controlled_outbound_internet`
11. `portable_operational_dashboard`

## Task / resolver / evidence

12. `deterministic_task_fingerprint`
13. `resolve_before_research`
14. `content_addressed_evidence_store`

## External agents

15. `mimo_intake_validation`

**Итого: 15 реальных system skills в portable runtime corpus.**

Правило следующего цикла: сначала попытаться `REUSE → EXTEND → MERGE`, и только после доказанного capability gap создавать шестнадцатый skill.

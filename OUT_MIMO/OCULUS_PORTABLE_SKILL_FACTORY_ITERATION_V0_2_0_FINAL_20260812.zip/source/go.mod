module github.com/worlbotcontent-commits/SMM

go 1.26

package main

import (
	"context"
	"flag"
	"log"
	"os/signal"
	"syscall"

	"github.com/worlbotcontent-commits/SMM/internal/app"
	"github.com/worlbotcontent-commits/SMM/internal/config"
)

func main() {
	configPath := flag.String("config", "config/config.json", "path to portable JSON config")
	flag.Parse()

	cfg, err := config.Load(*configPath)
	if err != nil {
		log.Fatalf("load config: %v", err)
	}

	a, err := app.New(cfg)
	if err != nil {
		log.Fatalf("init app: %v", err)
	}

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	if err := a.Run(ctx); err != nil {
		log.Fatalf("run app: %v", err)
	}
}

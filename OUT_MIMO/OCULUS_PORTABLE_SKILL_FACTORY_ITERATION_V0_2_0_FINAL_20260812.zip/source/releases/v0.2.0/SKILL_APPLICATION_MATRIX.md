# v0.2.0 — Skill extraction / rebuild / application matrix

The purpose of this matrix is to prove that skills are not merely listed in the book. Each skill must affect an implementation, validation or next-step decision.

| Skill | Action this cycle | Applied to | Disposition |
|---|---|---|---|
| `chapter_one_architecture_recheck` | REUSE | Book rebuilt from goal/invariants before adding code | ACTIVE |
| `atomic_decomposition_before_implementation` | CREATE_NEW | Task/Resolver/Evidence/MIMO/Quality/UI molecules were split into testable atoms | ACTIVE |
| `speed_without_accuracy_loss` | REUSE | Defined acceleration acceptance rule | ACTIVE |
| `deterministic_fast_path` | REUSE | Task fingerprint, resolver prefilter, MIMO empty-check | ACTIVE |
| `bounded_parallelism` | REUSE | Retained Internet concurrency policy; future scheduler boundary | ACTIVE |
| `incremental_diff_processing` | REUSE | Added independent packages without replacing stable runtime primitives | ACTIVE |
| `reference_vs_candidate_equivalence_gate` | REUSE + IMPLEMENT | `internal/quality` executable JSON equivalence primitive | ACTIVE |
| `portable_runtime_integrity` | REUSE + EXTEND | Relative storage/assets + Windows x64 build + mandatory iteration ZIP handoff | ACTIVE |
| `controlled_outbound_internet` | REUSE | Redirect policy remains enforced and tested | ACTIVE |
| `mimo_intake_validation` | EXTEND | Added non-blocking rule and deterministic batch fingerprint scan | ACTIVE |
| `deterministic_task_fingerprint` | CREATE_NEW → REBUILD | Task identity; rebuilt after CI exposed case-canonicalization defect | ACTIVE |
| `resolve_before_research` | CREATE_NEW | Resolver v1 and `/api/v1/skills/resolve` | ACTIVE |
| `content_addressed_evidence_store` | CREATE_NEW | Immutable evidence package and API | ACTIVE |
| `evidence_complete_cache` | REUSE | Evidence identity designed as prerequisite for safe future cache reuse | ACTIVE / CACHE NOT YET IMPLEMENTED |
| `portable_operational_dashboard` | CREATE_NEW → APPLY | Dark self-contained command center wired to real localhost API, plus offline contract test | ACTIVE |

## Dedup decisions

- No new skill named `nonblocking_mimo` was created. The rule extends `mimo_intake_validation`.
- No new skill named `json_accuracy_gate` was created. Executable logic implements the existing `reference_vs_candidate_equivalence_gate` concept.
- No new skill named `redirect_allowlist` was created. It remains an atom inside `controlled_outbound_internet`.
- No separate skills were created for sidebar, dark theme, metrics cards or registry table. They are atoms/molecules of `portable_operational_dashboard` rather than independently reusable capabilities at the current evidence level.

## Rebuild loop

`BOOK CLAIM → ATOM → EXISTING SKILL SEARCH → REUSE/EXTEND/CREATE → CODE/TEST → FAILURE EVIDENCE → SKILL PATCH → RE-APPLY`

Concrete examples in this iteration:

1. `Task equivalence requirement → deterministic_task_fingerprint → implementation → CI regression → canonicalization fix → SKILL.md rebuild → regression retained as quality gate`.
2. `User operational-dashboard requirement → UI substance/molecule/atom decomposition → portable_operational_dashboard → dashboard rebuild → offline/API contract test → reusable UI skill retained for later iterations`.

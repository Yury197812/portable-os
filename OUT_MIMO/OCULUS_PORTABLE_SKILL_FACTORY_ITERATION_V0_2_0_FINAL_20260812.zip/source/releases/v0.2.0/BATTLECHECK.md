# OCULUS Portable v0.2.0 — Battlecheck

Iteration scope: Task Intake, Skill Resolver v1, Evidence Store, MIMO Inbox Scanner, accuracy equivalence primitive, API/dashboard and portable release pipeline.

## Cases

| # | Attack / failure mode | Expected invariant | Result |
|---|---|---|---|
| 1 | Same task with surfaces in different order | Same task fingerprint | PASS |
| 2 | Same task with query case/whitespace differences | Same task fingerprint under current case-insensitive task schema | **FAILED first CI → FIXED** |
| 3 | Missing required task fields | Reject before research | PASS |
| 4 | Exact skill ID exists | `REUSE`, no research required | PASS |
| 5 | Similar ambiguous skills | Never automatic merge | PASS |
| 6 | Identical evidence captured twice | Same evidence identity / idempotent reuse | PASS |
| 7 | Evidence content mutated after capture | Read fails integrity check | PASS |
| 8 | MIMO inbox missing/empty | Empty non-blocking result | PASS |
| 9 | Same MIMO batch scanned repeatedly | Stable batch fingerprint | PASS |
| 10 | JSON output differs only by object-key order | Equivalent | PASS |
| 11 | Fast candidate changes semantic JSON value | Equivalence fails regardless of speed | PASS |
| 12 | HTTP redirect leaves host allowlist | Network request blocked | PASS from previous cycle and retained |

## Important defect discovered by the cycle

The first CI run of v0.2.0 showed that query deduplication was case-insensitive but the retained canonical query preserved the first encountered case. Two otherwise equivalent tasks could therefore hash differently depending on input representation.

Root cause atom:

`dedup_key != stored_canonical_value`

Fix:

All fields declared case-insensitive by the current Task Schema now use a canonical lower-case + whitespace-normalized representation before deduplication, sorting and fingerprinting.

The extracted `deterministic_task_fingerprint` skill was rebuilt from this failure evidence so the same class of defect is checked in future implementations.

## Unresolved risks carried to the next cycle

- Task Schema itself is not yet versioned into the fingerprint envelope.
- Global Evidence Store write mutex preserves correctness but may become a throughput bottleneck.
- Resolver v1 deterministic token overlap is intentionally shallow and needs metadata/index/semantic fallback.
- JSON equivalence is not a universal comparator for rank lists, graphs, generated content or probabilistic outputs.
- Evidence API currently buffers request content in memory.
- Research Job state machine and source policy layer are not implemented yet.

No unresolved item above is hidden by the release; each becomes explicit input to the next Chapter-1 recheck.

# app

Product-shell layer for the portable application.

Current executable implementation lives in `cmd/oculus-portable/` + `internal/app/`.

This top-level zone is reserved for product-level assets that are not engine internals: portable manifests, desktop shell integration, future updater/rollback UX, user profiles and app-level policies.

The runtime must remain usable without a traditional installer.

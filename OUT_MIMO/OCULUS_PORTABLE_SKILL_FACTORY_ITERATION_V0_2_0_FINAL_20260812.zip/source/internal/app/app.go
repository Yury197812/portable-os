package app

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"github.com/worlbotcontent-commits/SMM/internal/config"
	"github.com/worlbotcontent-commits/SMM/internal/evidence"
	"github.com/worlbotcontent-commits/SMM/internal/internet"
	"github.com/worlbotcontent-commits/SMM/internal/mimo"
	"github.com/worlbotcontent-commits/SMM/internal/skills"
	"github.com/worlbotcontent-commits/SMM/internal/state"
	"github.com/worlbotcontent-commits/SMM/internal/tasks"
)

type App struct {
	cfg       config.Config
	internet  *internet.Client
	skills    *skills.Registry
	state     *state.Store
	evidence  *evidence.Store
	mimoInbox *mimo.Inbox
	server    *http.Server
}

func New(cfg config.Config) (*App, error) {
	if err := cfg.Prepare(); err != nil {
		return nil, err
	}
	store, err := state.New(cfg.DataDir)
	if err != nil {
		return nil, err
	}
	evidenceStore, err := evidence.New(cfg.EvidenceDir())
	if err != nil {
		return nil, err
	}
	client := internet.New(internet.Config{
		AllowedHosts:     cfg.Internet.AllowedHosts,
		MaxConcurrent:    cfg.Internet.MaxConcurrent,
		Timeout:          cfg.InternetTimeout(),
		MaxResponseBytes: cfg.Internet.MaxResponseBytes,
		UserAgent:        cfg.Internet.UserAgent,
	})
	return &App{
		cfg:       cfg,
		internet:  client,
		skills:    skills.New(cfg.SkillsDir),
		state:     store,
		evidence:  evidenceStore,
		mimoInbox: mimo.NewInbox(cfg.MIMOInboxDir),
	}, nil
}

func (a *App) Run(ctx context.Context) error {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /api/v1/health", a.handleHealth)
	mux.HandleFunc("GET /api/v1/skills", a.handleSkills)
	mux.HandleFunc("POST /api/v1/skills/resolve", a.handleResolveSkills)
	mux.HandleFunc("POST /api/v1/tasks", a.handleCreateTask)
	mux.HandleFunc("POST /api/v1/evidence", a.handlePutEvidence)
	mux.HandleFunc("GET /api/v1/evidence/{id}", a.handleGetEvidence)
	mux.HandleFunc("GET /api/v1/mimo/inbox", a.handleMIMOInbox)
	mux.HandleFunc("POST /api/v1/fetch", a.handleFetch)
	mux.HandleFunc("GET /api/v1/events", a.handleEvents)

	if info, err := os.Stat(a.cfg.DashboardDir); err == nil && info.IsDir() {
		fs := http.FileServer(http.Dir(filepath.Clean(a.cfg.DashboardDir)))
		mux.Handle("GET /", fs)
	} else {
		mux.HandleFunc("GET /", func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Content-Type", "text/plain; charset=utf-8")
			_, _ = w.Write([]byte("OCULUS Portable is running; dashboard directory not found."))
		})
	}

	a.server = &http.Server{
		Addr:              a.cfg.Listen,
		Handler:           requestLog(mux),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       15 * time.Second,
		WriteTimeout:      30 * time.Second,
		IdleTimeout:       60 * time.Second,
	}

	errCh := make(chan error, 1)
	go func() {
		log.Printf("OCULUS Portable listening on http://%s", a.cfg.Listen)
		if err := a.server.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			errCh <- err
			return
		}
		errCh <- nil
	}()

	select {
	case <-ctx.Done():
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		return a.server.Shutdown(shutdownCtx)
	case err := <-errCh:
		return err
	}
}

func (a *App) handleHealth(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{
		"status":  "ok",
		"service": "oculus-portable",
		"version": "0.2.0",
		"time":    time.Now().UTC(),
	})
}

func (a *App) handleSkills(w http.ResponseWriter, r *http.Request) {
	items, err := a.skills.List()
	if err != nil {
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"skills": items, "count": len(items)})
}

func (a *App) handleResolveSkills(w http.ResponseWriter, r *http.Request) {
	var req skills.ResolveQuery
	if err := decodeStrict(w, r, 128<<10, &req); err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	resolution, err := a.skills.Resolve(req)
	if err != nil {
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	_, _ = a.state.Append("skills.resolve", map[string]any{
		"decision":        resolution.Decision,
		"candidate_count": len(resolution.Candidates),
		"ambiguous":       resolution.Ambiguous,
	})
	writeJSON(w, http.StatusOK, resolution)
}

func (a *App) handleCreateTask(w http.ResponseWriter, r *http.Request) {
	var req tasks.Input
	if err := decodeStrict(w, r, 256<<10, &req); err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	task, err := tasks.New(req)
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	_, _ = a.state.Append("task.created", map[string]any{
		"task_id":     task.ID,
		"fingerprint": task.Fingerprint,
		"platform":    task.Input.Platform,
		"surfaces":    task.Input.Surfaces,
	})
	writeJSON(w, http.StatusCreated, task)
}

type evidenceRequest struct {
	Source        string `json:"source"`
	SourceVersion string `json:"source_version,omitempty"`
	MediaType     string `json:"media_type"`
	ContentText   string `json:"content_text,omitempty"`
	ContentBase64 string `json:"content_base64,omitempty"`
}

func (a *App) handlePutEvidence(w http.ResponseWriter, r *http.Request) {
	var req evidenceRequest
	if err := decodeStrict(w, r, 8<<20, &req); err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	if (req.ContentText == "") == (req.ContentBase64 == "") {
		writeError(w, http.StatusBadRequest, errors.New("provide exactly one of content_text or content_base64"))
		return
	}
	content := []byte(req.ContentText)
	if req.ContentBase64 != "" {
		decoded, err := base64.StdEncoding.DecodeString(req.ContentBase64)
		if err != nil {
			writeError(w, http.StatusBadRequest, errors.New("content_base64 is invalid"))
			return
		}
		content = decoded
	}
	rec, err := a.evidence.Put(evidence.PutInput{
		Source:        req.Source,
		SourceVersion: req.SourceVersion,
		MediaType:     req.MediaType,
		Content:       content,
	})
	if err != nil {
		writeError(w, http.StatusBadRequest, err)
		return
	}
	_, _ = a.state.Append("evidence.captured", map[string]any{
		"evidence_id": rec.ID,
		"source":      rec.Source,
		"sha256":      rec.ContentSHA256,
		"size":        rec.Size,
	})
	writeJSON(w, http.StatusCreated, rec)
}

func (a *App) handleGetEvidence(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	if r.URL.Query().Get("content") == "1" {
		content, rec, err := a.evidence.ReadContent(id)
		if err != nil {
			if errors.Is(err, os.ErrNotExist) {
				writeError(w, http.StatusNotFound, errors.New("evidence not found"))
				return
			}
			writeError(w, http.StatusInternalServerError, err)
			return
		}
		writeJSON(w, http.StatusOK, map[string]any{
			"record":         rec,
			"content_base64": base64.StdEncoding.EncodeToString(content),
		})
		return
	}
	rec, err := a.evidence.Get(id)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			writeError(w, http.StatusNotFound, errors.New("evidence not found"))
			return
		}
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	writeJSON(w, http.StatusOK, rec)
}

func (a *App) handleMIMOInbox(w http.ResponseWriter, r *http.Request) {
	batches, err := a.mimoInbox.List()
	if err != nil {
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"batches":  batches,
		"count":    len(batches),
		"blocking": false,
	})
}

type fetchRequest struct {
	URL string `json:"url"`
}

func (a *App) handleFetch(w http.ResponseWriter, r *http.Request) {
	var req fetchRequest
	if err := decodeStrict(w, r, 64<<10, &req); err != nil || req.URL == "" {
		writeError(w, http.StatusBadRequest, fmt.Errorf("invalid request body"))
		return
	}
	result, err := a.internet.Fetch(r.Context(), req.URL)
	if err != nil {
		_, _ = a.state.Append("internet.fetch.failed", map[string]any{"url": req.URL, "error": err.Error()})
		writeError(w, http.StatusBadGateway, err)
		return
	}
	_, _ = a.state.Append("internet.fetch.ok", map[string]any{
		"url":         result.URL,
		"status_code": result.StatusCode,
		"truncated":   result.Truncated,
	})
	writeJSON(w, http.StatusOK, result)
}

func (a *App) handleEvents(w http.ResponseWriter, r *http.Request) {
	items, err := a.state.Recent(100)
	if err != nil {
		writeError(w, http.StatusInternalServerError, err)
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"events": items, "count": len(items)})
}

func decodeStrict(w http.ResponseWriter, r *http.Request, maxBytes int64, dst any) error {
	dec := json.NewDecoder(http.MaxBytesReader(w, r.Body, maxBytes))
	dec.DisallowUnknownFields()
	if err := dec.Decode(dst); err != nil {
		return fmt.Errorf("invalid request body: %w", err)
	}
	var extra any
	if err := dec.Decode(&extra); !errors.Is(err, io.EOF) {
		if err == nil {
			return errors.New("request body must contain one JSON value")
		}
		return fmt.Errorf("invalid trailing data: %w", err)
	}
	return nil
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func writeError(w http.ResponseWriter, status int, err error) {
	writeJSON(w, status, map[string]any{"error": err.Error()})
}

func requestLog(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		started := time.Now()
		next.ServeHTTP(w, r)
		log.Printf("%s %s %s", r.Method, r.URL.Path, time.Since(started).Round(time.Millisecond))
	})
}

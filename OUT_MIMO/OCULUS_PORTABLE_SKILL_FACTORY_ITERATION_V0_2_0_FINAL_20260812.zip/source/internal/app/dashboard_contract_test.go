package app

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestDashboardPortableOperationalContract(t *testing.T) {
	path := filepath.Join("..", "..", "dashboard", "index.html")
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	html := string(b)

	required := []string{
		"/api/v1/health",
		"/api/v1/tasks",
		"/api/v1/skills",
		"/api/v1/skills/resolve",
		"/api/v1/evidence",
		"/api/v1/mimo/inbox",
		"/api/v1/fetch",
		"/api/v1/events",
		"OCULUS Pipeline",
		"Resolve Before Research",
		"Evidence Vault",
		"Controlled Internet",
	}
	for _, needle := range required {
		if !strings.Contains(html, needle) {
			t.Fatalf("dashboard missing required operational element %q", needle)
		}
	}

	forbidden := []string{
		"<script src=\"http",
		"<script src='http",
		"<link href=\"http",
		"<link href='http",
		"fonts.googleapis.com",
		"cdn.jsdelivr.net",
		"unpkg.com",
	}
	lower := strings.ToLower(html)
	for _, needle := range forbidden {
		if strings.Contains(lower, strings.ToLower(needle)) {
			t.Fatalf("dashboard must remain self-contained; found %q", needle)
		}
	}
}

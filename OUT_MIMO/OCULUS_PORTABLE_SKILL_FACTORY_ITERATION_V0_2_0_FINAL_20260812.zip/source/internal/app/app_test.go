package app

import (
	"encoding/json"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/worlbotcontent-commits/SMM/internal/config"
)

func newTestApp(t *testing.T) *App {
	t.Helper()
	root := t.TempDir()
	cfg := config.Default()
	cfg.DataDir = filepath.Join(root, "data")
	cfg.SkillsDir = filepath.Join(root, "skills")
	cfg.DashboardDir = filepath.Join(root, "dashboard")
	cfg.MIMOInboxDir = filepath.Join(root, "MIMO", "inbox")
	if err := os.MkdirAll(filepath.Join(cfg.SkillsDir, "system", "resolve_before_research"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(cfg.SkillsDir, "system", "resolve_before_research", "SKILL.md"), []byte("# Resolve Before Research\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	a, err := New(cfg)
	if err != nil {
		t.Fatal(err)
	}
	return a
}

func TestCreateTaskEndpoint(t *testing.T) {
	a := newTestApp(t)
	body := `{"platform":"yandex","surfaces":["organic","neuro"],"niche":"flowers","language":"ru","content_type":"article","goal":"rank_and_cite"}`
	req := httptest.NewRequest("POST", "/api/v1/tasks", strings.NewReader(body))
	rec := httptest.NewRecorder()
	a.handleCreateTask(rec, req)
	if rec.Code != 201 {
		t.Fatalf("status=%d body=%s", rec.Code, rec.Body.String())
	}
	var got map[string]any
	if err := json.Unmarshal(rec.Body.Bytes(), &got); err != nil {
		t.Fatal(err)
	}
	if got["id"] == "" || got["fingerprint"] == "" {
		t.Fatalf("missing identity: %+v", got)
	}
}

func TestResolveEndpointReusesExactSkill(t *testing.T) {
	a := newTestApp(t)
	body := `{"requested_id":"system/resolve_before_research"}`
	req := httptest.NewRequest("POST", "/api/v1/skills/resolve", strings.NewReader(body))
	rec := httptest.NewRecorder()
	a.handleResolveSkills(rec, req)
	if rec.Code != 200 {
		t.Fatalf("status=%d body=%s", rec.Code, rec.Body.String())
	}
	if !strings.Contains(rec.Body.String(), `"decision":"REUSE"`) {
		t.Fatalf("unexpected resolution: %s", rec.Body.String())
	}
}

func TestEvidenceEndpointRoundTrip(t *testing.T) {
	a := newTestApp(t)
	body := `{"source":"unit-test","media_type":"text/plain","content_text":"evidence"}`
	req := httptest.NewRequest("POST", "/api/v1/evidence", strings.NewReader(body))
	rec := httptest.NewRecorder()
	a.handlePutEvidence(rec, req)
	if rec.Code != 201 {
		t.Fatalf("status=%d body=%s", rec.Code, rec.Body.String())
	}
	var captured struct {
		ID string `json:"id"`
	}
	if err := json.Unmarshal(rec.Body.Bytes(), &captured); err != nil {
		t.Fatal(err)
	}
	if captured.ID == "" {
		t.Fatal("missing evidence id")
	}

	getReq := httptest.NewRequest("GET", "/api/v1/evidence/"+captured.ID, nil)
	getReq.SetPathValue("id", captured.ID)
	getRec := httptest.NewRecorder()
	a.handleGetEvidence(getRec, getReq)
	if getRec.Code != 200 || !strings.Contains(getRec.Body.String(), captured.ID) {
		t.Fatalf("evidence get failed: status=%d body=%s", getRec.Code, getRec.Body.String())
	}
}

func TestMIMOInboxIsNonBlockingWhenEmpty(t *testing.T) {
	a := newTestApp(t)
	req := httptest.NewRequest("GET", "/api/v1/mimo/inbox", nil)
	rec := httptest.NewRecorder()
	a.handleMIMOInbox(rec, req)
	if rec.Code != 200 {
		t.Fatalf("status=%d body=%s", rec.Code, rec.Body.String())
	}
	if !strings.Contains(rec.Body.String(), `"blocking":false`) || !strings.Contains(rec.Body.String(), `"count":0`) {
		t.Fatalf("unexpected MIMO response: %s", rec.Body.String())
	}
}

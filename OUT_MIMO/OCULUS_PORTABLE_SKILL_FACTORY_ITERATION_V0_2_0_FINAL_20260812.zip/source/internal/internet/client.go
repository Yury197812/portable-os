package internet

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"
)

type Config struct {
	AllowedHosts     []string
	MaxConcurrent    int
	Timeout          time.Duration
	MaxResponseBytes int64
	UserAgent        string
}

type Client struct {
	http             *http.Client
	allowedHosts     []string
	sem              chan struct{}
	maxResponseBytes int64
	userAgent        string
}

type Result struct {
	URL        string              `json:"url"`
	StatusCode int                 `json:"status_code"`
	Header     map[string][]string `json:"header"`
	Body       string              `json:"body"`
	Truncated  bool                `json:"truncated"`
}

func New(cfg Config) *Client {
	if cfg.MaxConcurrent <= 0 {
		cfg.MaxConcurrent = 4
	}
	if cfg.Timeout <= 0 {
		cfg.Timeout = 20 * time.Second
	}
	if cfg.MaxResponseBytes <= 0 {
		cfg.MaxResponseBytes = 4 << 20
	}
	transport := &http.Transport{
		Proxy:                 http.ProxyFromEnvironment,
		DialContext:           (&net.Dialer{Timeout: 10 * time.Second, KeepAlive: 30 * time.Second}).DialContext,
		ForceAttemptHTTP2:     true,
		MaxIdleConns:          32,
		IdleConnTimeout:       60 * time.Second,
		TLSHandshakeTimeout:   10 * time.Second,
		ResponseHeaderTimeout: cfg.Timeout,
	}
	c := &Client{
		allowedHosts:     normalizeHosts(cfg.AllowedHosts),
		sem:              make(chan struct{}, cfg.MaxConcurrent),
		maxResponseBytes: cfg.MaxResponseBytes,
		userAgent:        cfg.UserAgent,
	}
	c.http = &http.Client{
		Timeout:   cfg.Timeout,
		Transport: transport,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			if len(via) >= 10 {
				return errors.New("too many redirects")
			}
			if !c.hostAllowed(req.URL.Hostname()) {
				return fmt.Errorf("redirect host is not allowed: %s", req.URL.Hostname())
			}
			if req.URL.Scheme != "https" && req.URL.Scheme != "http" {
				return errors.New("redirected URL uses unsupported scheme")
			}
			return nil
		},
	}
	return c
}

func (c *Client) Fetch(ctx context.Context, rawURL string) (Result, error) {
	u, err := url.Parse(rawURL)
	if err != nil {
		return Result{}, err
	}
	if u.Scheme != "https" && u.Scheme != "http" {
		return Result{}, errors.New("only http/https URLs are allowed")
	}
	if !c.hostAllowed(u.Hostname()) {
		return Result{}, fmt.Errorf("outbound host is not allowed: %s", u.Hostname())
	}

	select {
	case c.sem <- struct{}{}:
		defer func() { <-c.sem }()
	case <-ctx.Done():
		return Result{}, ctx.Err()
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	if err != nil {
		return Result{}, err
	}
	if c.userAgent != "" {
		req.Header.Set("User-Agent", c.userAgent)
	}

	resp, err := c.http.Do(req)
	if err != nil {
		return Result{}, err
	}
	defer resp.Body.Close()

	limited := io.LimitReader(resp.Body, c.maxResponseBytes+1)
	body, err := io.ReadAll(limited)
	if err != nil {
		return Result{}, err
	}
	truncated := int64(len(body)) > c.maxResponseBytes
	if truncated {
		body = body[:c.maxResponseBytes]
	}

	return Result{
		URL:        resp.Request.URL.String(),
		StatusCode: resp.StatusCode,
		Header:     resp.Header.Clone(),
		Body:       string(body),
		Truncated:  truncated,
	}, nil
}

func normalizeHosts(hosts []string) []string {
	out := make([]string, 0, len(hosts))
	for _, h := range hosts {
		h = strings.ToLower(strings.TrimSpace(h))
		if h != "" {
			out = append(out, h)
		}
	}
	return out
}

func (c *Client) hostAllowed(host string) bool {
	host = strings.ToLower(strings.TrimSpace(host))
	if host == "" {
		return false
	}
	for _, rule := range c.allowedHosts {
		if rule == host {
			return true
		}
		if strings.HasPrefix(rule, "*.") {
			suffix := strings.TrimPrefix(rule, "*")
			if strings.HasSuffix(host, suffix) && host != strings.TrimPrefix(suffix, ".") {
				return true
			}
		}
	}
	return false
}

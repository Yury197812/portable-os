package internet

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestHostAllowlist(t *testing.T) {
	c := New(Config{AllowedHosts: []string{"example.com", "*.example.org"}})
	cases := []struct {
		host string
		want bool
	}{
		{"example.com", true},
		{"sub.example.com", false},
		{"api.example.org", true},
		{"deep.api.example.org", true},
		{"example.org", false},
		{"evil-example.org", false},
		{"", false},
	}
	for _, tc := range cases {
		if got := c.hostAllowed(tc.host); got != tc.want {
			t.Fatalf("hostAllowed(%q)=%v want %v", tc.host, got, tc.want)
		}
	}
}

func TestRedirectCannotEscapeAllowlist(t *testing.T) {
	target := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte("should not be reached"))
	}))
	defer target.Close()

	source := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		redirect := strings.Replace(target.URL, "127.0.0.1", "localhost", 1)
		http.Redirect(w, r, redirect, http.StatusFound)
	}))
	defer source.Close()

	c := New(Config{
		AllowedHosts:     []string{"127.0.0.1"},
		Timeout:          2 * time.Second,
		MaxConcurrent:    1,
		MaxResponseBytes: 1024,
	})
	_, err := c.Fetch(context.Background(), source.URL)
	if err == nil || !strings.Contains(err.Error(), "redirect host is not allowed") {
		t.Fatalf("expected blocked redirect, got %v", err)
	}
}

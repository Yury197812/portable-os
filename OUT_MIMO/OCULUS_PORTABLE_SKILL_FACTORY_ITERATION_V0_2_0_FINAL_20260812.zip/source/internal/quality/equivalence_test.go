package quality

import (
	"context"
	"testing"
)

func TestEquivalentJSONIgnoresObjectKeyOrder(t *testing.T) {
	eq, err := EquivalentJSON([]byte(`{"a":1,"b":[2,3]}`), []byte(`{"b":[2,3],"a":1}`))
	if err != nil {
		t.Fatal(err)
	}
	if !eq {
		t.Fatal("expected equivalent JSON")
	}
}

func TestCompareJSONRejectsAccuracyRegression(t *testing.T) {
	got, err := CompareJSON(context.Background(),
		func(context.Context) ([]byte, error) { return []byte(`{"result":"correct"}`), nil },
		func(context.Context) ([]byte, error) { return []byte(`{"result":"wrong"}`), nil },
	)
	if err != nil {
		t.Fatal(err)
	}
	if got.Equivalent {
		t.Fatal("candidate with different output must fail equivalence")
	}
}

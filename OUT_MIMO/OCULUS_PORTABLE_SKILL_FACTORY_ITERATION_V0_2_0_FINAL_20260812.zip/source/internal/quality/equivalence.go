package quality

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"reflect"
	"time"
)

type Runner func(context.Context) ([]byte, error)

type Comparison struct {
	Equivalent        bool          `json:"equivalent"`
	ReferenceDuration time.Duration `json:"reference_duration"`
	CandidateDuration time.Duration `json:"candidate_duration"`
	Speedup           float64       `json:"speedup"`
	ReferenceOutput   []byte        `json:"-"`
	CandidateOutput   []byte        `json:"-"`
}

func CompareJSON(ctx context.Context, reference, candidate Runner) (Comparison, error) {
	if reference == nil || candidate == nil {
		return Comparison{}, errors.New("reference and candidate runners are required")
	}
	start := time.Now()
	ref, err := reference(ctx)
	if err != nil {
		return Comparison{}, fmt.Errorf("reference failed: %w", err)
	}
	refDuration := time.Since(start)

	start = time.Now()
	cand, err := candidate(ctx)
	if err != nil {
		return Comparison{}, fmt.Errorf("candidate failed: %w", err)
	}
	candDuration := time.Since(start)

	eq, err := EquivalentJSON(ref, cand)
	if err != nil {
		return Comparison{}, err
	}
	speedup := 0.0
	if candDuration > 0 {
		speedup = float64(refDuration) / float64(candDuration)
	}
	return Comparison{
		Equivalent:        eq,
		ReferenceDuration: refDuration,
		CandidateDuration: candDuration,
		Speedup:           speedup,
		ReferenceOutput:   ref,
		CandidateOutput:   cand,
	}, nil
}

func EquivalentJSON(a, b []byte) (bool, error) {
	av, err := decodeJSON(a)
	if err != nil {
		return false, fmt.Errorf("invalid reference JSON: %w", err)
	}
	bv, err := decodeJSON(b)
	if err != nil {
		return false, fmt.Errorf("invalid candidate JSON: %w", err)
	}
	return reflect.DeepEqual(av, bv), nil
}

func decodeJSON(b []byte) (any, error) {
	dec := json.NewDecoder(bytes.NewReader(b))
	dec.UseNumber()
	var v any
	if err := dec.Decode(&v); err != nil {
		return nil, err
	}
	var trailing any
	if err := dec.Decode(&trailing); !errors.Is(err, io.EOF) {
		if err == nil {
			return nil, errors.New("multiple JSON values")
		}
		return nil, err
	}
	return v, nil
}

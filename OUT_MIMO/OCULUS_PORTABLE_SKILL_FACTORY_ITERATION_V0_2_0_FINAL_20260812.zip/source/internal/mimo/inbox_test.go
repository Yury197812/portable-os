package mimo

import (
	"os"
	"path/filepath"
	"testing"
)

func TestInboxFingerprintStableAcrossFileCreationOrder(t *testing.T) {
	root := t.TempDir()
	batch := filepath.Join(root, "batch-001")
	if err := os.MkdirAll(filepath.Join(batch, "nested"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(batch, "z.txt"), []byte("z"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(batch, "nested", "a.txt"), []byte("a"), 0o644); err != nil {
		t.Fatal(err)
	}

	inbox := NewInbox(root)
	first, err := inbox.List()
	if err != nil {
		t.Fatal(err)
	}
	second, err := inbox.List()
	if err != nil {
		t.Fatal(err)
	}
	if len(first) != 1 || len(second) != 1 {
		t.Fatalf("unexpected batches: %+v %+v", first, second)
	}
	if first[0].Fingerprint != second[0].Fingerprint {
		t.Fatalf("fingerprint changed: %s != %s", first[0].Fingerprint, second[0].Fingerprint)
	}
	if first[0].Files[0].Path != "nested/a.txt" || first[0].Files[1].Path != "z.txt" {
		t.Fatalf("files not sorted deterministically: %+v", first[0].Files)
	}
}

func TestInboxMissingRootIsEmpty(t *testing.T) {
	inbox := NewInbox(filepath.Join(t.TempDir(), "missing"))
	batches, err := inbox.List()
	if err != nil {
		t.Fatal(err)
	}
	if len(batches) != 0 {
		t.Fatalf("expected empty inbox, got %+v", batches)
	}
}

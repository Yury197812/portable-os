package mimo

import (
	"crypto/sha256"
	"encoding/hex"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

type File struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
	Size   int64  `json:"size"`
}

type Batch struct {
	ID          string `json:"id"`
	Path        string `json:"path"`
	Fingerprint string `json:"fingerprint"`
	Files       []File `json:"files"`
}

type Inbox struct {
	root string
}

func NewInbox(root string) *Inbox {
	return &Inbox{root: root}
}

func (i *Inbox) List() ([]Batch, error) {
	entries, err := os.ReadDir(i.root)
	if err != nil {
		if os.IsNotExist(err) {
			return []Batch{}, nil
		}
		return nil, err
	}
	batches := make([]Batch, 0)
	for _, entry := range entries {
		if !entry.IsDir() || strings.HasPrefix(entry.Name(), ".") {
			continue
		}
		batch, err := i.inspect(entry.Name())
		if err != nil {
			return nil, err
		}
		batches = append(batches, batch)
	}
	sort.Slice(batches, func(a, b int) bool { return batches[a].ID < batches[b].ID })
	return batches, nil
}

func (i *Inbox) inspect(id string) (Batch, error) {
	root := filepath.Join(i.root, id)
	files := make([]File, 0)
	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() {
			return nil
		}
		rel, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}
		f, err := os.Open(path)
		if err != nil {
			return err
		}
		h := sha256.New()
		n, copyErr := io.Copy(h, f)
		closeErr := f.Close()
		if copyErr != nil {
			return copyErr
		}
		if closeErr != nil {
			return closeErr
		}
		files = append(files, File{Path: filepath.ToSlash(rel), SHA256: hex.EncodeToString(h.Sum(nil)), Size: n})
		return nil
	})
	if err != nil {
		return Batch{}, err
	}
	sort.Slice(files, func(a, b int) bool { return files[a].Path < files[b].Path })

	h := sha256.New()
	for _, f := range files {
		_, _ = io.WriteString(h, f.Path)
		_, _ = io.WriteString(h, "\x00")
		_, _ = io.WriteString(h, f.SHA256)
		_, _ = io.WriteString(h, "\n")
	}
	return Batch{
		ID:          id,
		Path:        filepath.ToSlash(root),
		Fingerprint: hex.EncodeToString(h.Sum(nil)),
		Files:       files,
	}, nil
}

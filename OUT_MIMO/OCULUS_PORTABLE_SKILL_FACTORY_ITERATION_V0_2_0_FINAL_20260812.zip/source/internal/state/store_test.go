package state

import "testing"

func TestAppendAndRecent(t *testing.T) {
	s, err := New(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	if _, err := s.Append("test.one", map[string]any{"n": 1}); err != nil {
		t.Fatal(err)
	}
	if _, err := s.Append("test.two", map[string]any{"n": 2}); err != nil {
		t.Fatal(err)
	}
	items, err := s.Recent(1)
	if err != nil {
		t.Fatal(err)
	}
	if len(items) != 1 || items[0].Type != "test.two" {
		t.Fatalf("unexpected recent events: %+v", items)
	}
}

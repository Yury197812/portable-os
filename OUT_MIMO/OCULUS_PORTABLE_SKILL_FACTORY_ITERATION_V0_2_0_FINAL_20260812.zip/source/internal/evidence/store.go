package evidence

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type PutInput struct {
	Source        string `json:"source"`
	SourceVersion string `json:"source_version,omitempty"`
	MediaType     string `json:"media_type"`
	Content       []byte `json:"-"`
}

type Record struct {
	ID            string    `json:"id"`
	ContentSHA256 string    `json:"content_sha256"`
	Source        string    `json:"source"`
	SourceVersion string    `json:"source_version,omitempty"`
	MediaType     string    `json:"media_type"`
	Size          int64     `json:"size"`
	CapturedAt    time.Time `json:"captured_at"`
	ContentPath   string    `json:"content_path"`
}

type Store struct {
	root string
	mu   sync.Mutex
}

func New(root string) (*Store, error) {
	if strings.TrimSpace(root) == "" {
		return nil, errors.New("evidence root is required")
	}
	if err := os.MkdirAll(root, 0o755); err != nil {
		return nil, err
	}
	return &Store{root: root}, nil
}

func (s *Store) Put(in PutInput) (Record, error) {
	in.Source = strings.TrimSpace(in.Source)
	in.SourceVersion = strings.TrimSpace(in.SourceVersion)
	in.MediaType = strings.TrimSpace(in.MediaType)
	if in.Source == "" {
		return Record{}, errors.New("source is required")
	}
	if in.MediaType == "" {
		return Record{}, errors.New("media_type is required")
	}
	contentHash := sha256.Sum256(in.Content)
	contentSHA := hex.EncodeToString(contentHash[:])
	envelope := strings.Join([]string{in.Source, in.SourceVersion, in.MediaType, contentSHA}, "\n")
	evidenceHash := sha256.Sum256([]byte(envelope))
	id := hex.EncodeToString(evidenceHash[:])

	s.mu.Lock()
	defer s.mu.Unlock()

	dir := filepath.Join(s.root, id[:2])
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return Record{}, err
	}
	contentPath := filepath.Join(dir, id+".bin")
	metaPath := filepath.Join(dir, id+".json")

	if rec, err := s.Get(id); err == nil {
		if rec.ContentSHA256 != contentSHA || rec.Source != in.Source || rec.SourceVersion != in.SourceVersion || rec.MediaType != in.MediaType {
			return Record{}, fmt.Errorf("immutable evidence collision for %s", id)
		}
		return rec, nil
	} else if !errors.Is(err, os.ErrNotExist) {
		return Record{}, err
	}

	if err := atomicWrite(contentPath, in.Content, 0o644); err != nil {
		return Record{}, err
	}
	rec := Record{
		ID:            id,
		ContentSHA256: contentSHA,
		Source:        in.Source,
		SourceVersion: in.SourceVersion,
		MediaType:     in.MediaType,
		Size:          int64(len(in.Content)),
		CapturedAt:    time.Now().UTC(),
		ContentPath:   filepath.ToSlash(filepath.Join(id[:2], id+".bin")),
	}
	meta, err := json.MarshalIndent(rec, "", "  ")
	if err != nil {
		_ = os.Remove(contentPath)
		return Record{}, err
	}
	if err := atomicWrite(metaPath, append(meta, '\n'), 0o644); err != nil {
		_ = os.Remove(contentPath)
		return Record{}, err
	}
	return rec, nil
}

func (s *Store) Get(id string) (Record, error) {
	id = strings.ToLower(strings.TrimSpace(id))
	if len(id) != 64 {
		return Record{}, os.ErrNotExist
	}
	for _, r := range id {
		if !((r >= '0' && r <= '9') || (r >= 'a' && r <= 'f')) {
			return Record{}, os.ErrNotExist
		}
	}
	metaPath := filepath.Join(s.root, id[:2], id+".json")
	b, err := os.ReadFile(metaPath)
	if err != nil {
		return Record{}, err
	}
	var rec Record
	if err := json.Unmarshal(b, &rec); err != nil {
		return Record{}, err
	}
	if rec.ID != id {
		return Record{}, errors.New("evidence metadata id mismatch")
	}
	return rec, nil
}

func (s *Store) ReadContent(id string) ([]byte, Record, error) {
	rec, err := s.Get(id)
	if err != nil {
		return nil, Record{}, err
	}
	path := filepath.Join(s.root, filepath.FromSlash(rec.ContentPath))
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, Record{}, err
	}
	sum := sha256.Sum256(b)
	if hex.EncodeToString(sum[:]) != rec.ContentSHA256 {
		return nil, Record{}, errors.New("evidence content hash mismatch")
	}
	return b, rec, nil
}

func atomicWrite(path string, data []byte, mode os.FileMode) error {
	dir := filepath.Dir(path)
	f, err := os.CreateTemp(dir, ".tmp-*")
	if err != nil {
		return err
	}
	tmp := f.Name()
	defer os.Remove(tmp)
	if err := f.Chmod(mode); err != nil {
		_ = f.Close()
		return err
	}
	if _, err := f.Write(data); err != nil {
		_ = f.Close()
		return err
	}
	if err := f.Sync(); err != nil {
		_ = f.Close()
		return err
	}
	if err := f.Close(); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

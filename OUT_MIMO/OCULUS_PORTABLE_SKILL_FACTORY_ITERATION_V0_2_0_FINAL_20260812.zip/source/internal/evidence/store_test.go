package evidence

import (
	"os"
	"path/filepath"
	"testing"
)

func TestPutIsDeterministicAndImmutable(t *testing.T) {
	store, err := New(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	in := PutInput{Source: "https://example.com/a", SourceVersion: "etag:1", MediaType: "text/plain", Content: []byte("alpha")}
	a, err := store.Put(in)
	if err != nil {
		t.Fatal(err)
	}
	b, err := store.Put(in)
	if err != nil {
		t.Fatal(err)
	}
	if a.ID != b.ID || a.ContentSHA256 != b.ContentSHA256 {
		t.Fatalf("same evidence produced different identity: %+v %+v", a, b)
	}
	content, rec, err := store.ReadContent(a.ID)
	if err != nil {
		t.Fatal(err)
	}
	if string(content) != "alpha" || rec.ID != a.ID {
		t.Fatalf("unexpected evidence: %q %+v", content, rec)
	}
}

func TestReadContentDetectsTampering(t *testing.T) {
	root := t.TempDir()
	store, err := New(root)
	if err != nil {
		t.Fatal(err)
	}
	rec, err := store.Put(PutInput{Source: "unit-test", MediaType: "text/plain", Content: []byte("original")})
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(root, filepath.FromSlash(rec.ContentPath))
	if err := os.WriteFile(path, []byte("changed"), 0o644); err != nil {
		t.Fatal(err)
	}
	if _, _, err := store.ReadContent(rec.ID); err == nil {
		t.Fatal("expected content hash mismatch")
	}
}

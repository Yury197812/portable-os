package config

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"time"
)

type Internet struct {
	AllowedHosts     []string `json:"allowed_hosts"`
	MaxConcurrent    int      `json:"max_concurrent"`
	TimeoutSeconds   int      `json:"timeout_seconds"`
	MaxResponseBytes int64    `json:"max_response_bytes"`
	UserAgent        string   `json:"user_agent"`
}

type Config struct {
	Listen       string   `json:"listen"`
	DataDir      string   `json:"data_dir"`
	SkillsDir    string   `json:"skills_dir"`
	DashboardDir string   `json:"dashboard_dir"`
	MIMOInboxDir string   `json:"mimo_inbox_dir"`
	Internet     Internet `json:"internet"`
}

func Default() Config {
	return Config{
		Listen:       "127.0.0.1:8787",
		DataDir:      "data",
		SkillsDir:    "skills",
		DashboardDir: "dashboard",
		MIMOInboxDir: filepath.ToSlash(filepath.Join("MIMO", "inbox")),
		Internet: Internet{
			AllowedHosts:     []string{},
			MaxConcurrent:    4,
			TimeoutSeconds:   20,
			MaxResponseBytes: 4 << 20,
			UserAgent:        "OCULUS-Portable/0.2",
		},
	}
}

func Load(path string) (Config, error) {
	cfg := Default()
	if path == "" {
		return cfg, nil
	}
	b, err := os.ReadFile(path)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return cfg, nil
		}
		return Config{}, err
	}
	if err := json.Unmarshal(b, &cfg); err != nil {
		return Config{}, err
	}
	cfg.normalize()
	return cfg, nil
}

func (c *Config) normalize() {
	if c.Listen == "" {
		c.Listen = "127.0.0.1:8787"
	}
	if c.DataDir == "" {
		c.DataDir = "data"
	}
	if c.SkillsDir == "" {
		c.SkillsDir = "skills"
	}
	if c.DashboardDir == "" {
		c.DashboardDir = "dashboard"
	}
	if c.MIMOInboxDir == "" {
		c.MIMOInboxDir = filepath.ToSlash(filepath.Join("MIMO", "inbox"))
	}
	if c.Internet.MaxConcurrent <= 0 {
		c.Internet.MaxConcurrent = 4
	}
	if c.Internet.TimeoutSeconds <= 0 {
		c.Internet.TimeoutSeconds = 20
	}
	if c.Internet.MaxResponseBytes <= 0 {
		c.Internet.MaxResponseBytes = 4 << 20
	}
	if c.Internet.UserAgent == "" {
		c.Internet.UserAgent = "OCULUS-Portable/0.2"
	}
}

func (c Config) Prepare() error {
	if err := os.MkdirAll(filepath.Clean(c.DataDir), 0o755); err != nil {
		return err
	}
	return os.MkdirAll(filepath.Join(filepath.Clean(c.DataDir), "evidence"), 0o755)
}

func (c Config) EvidenceDir() string {
	return filepath.Join(c.DataDir, "evidence")
}

func (c Config) InternetTimeout() time.Duration {
	return time.Duration(c.Internet.TimeoutSeconds) * time.Second
}

package skills

import (
	"os"
	"path/filepath"
	"testing"
)

func TestResolveExactReuse(t *testing.T) {
	root := t.TempDir()
	writeSkill(t, root, "system/speed_without_accuracy_loss", "# Speed Without Accuracy Loss\n")
	r := New(root)
	got, err := r.Resolve(ResolveQuery{RequestedID: "system/speed_without_accuracy_loss"})
	if err != nil {
		t.Fatal(err)
	}
	if got.Decision != "REUSE" || got.NeedsResearch {
		t.Fatalf("unexpected resolution: %+v", got)
	}
	if len(got.Candidates) != 1 || !got.Candidates[0].ExactMatch {
		t.Fatalf("expected exact candidate: %+v", got.Candidates)
	}
}

func TestResolveNeverAutoMergesAmbiguousCandidates(t *testing.T) {
	root := t.TempDir()
	writeSkill(t, root, "system/cache_evidence", "# Cache Evidence\n")
	writeSkill(t, root, "system/evidence_cache", "# Evidence Cache\n")
	r := New(root)
	got, err := r.Resolve(ResolveQuery{RequestedName: "evidence cache"})
	if err != nil {
		t.Fatal(err)
	}
	if got.AutoMerge {
		t.Fatal("deterministic resolver must never auto-merge")
	}
}

func writeSkill(t *testing.T, root, id, content string) {
	t.Helper()
	path := filepath.Join(root, filepath.FromSlash(id), "SKILL.md")
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatal(err)
	}
}

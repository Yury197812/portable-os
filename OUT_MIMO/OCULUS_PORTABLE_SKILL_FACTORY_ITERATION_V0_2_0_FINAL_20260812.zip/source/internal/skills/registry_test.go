package skills

import (
	"os"
	"path/filepath"
	"testing"
)

func TestRegistryListsSkillWithHash(t *testing.T) {
	root := t.TempDir()
	dir := filepath.Join(root, "core", "fast_path")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, "SKILL.md"), []byte("# Deterministic Fast Path\n\nBody\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	items, err := New(root).List()
	if err != nil {
		t.Fatal(err)
	}
	if len(items) != 1 {
		t.Fatalf("got %d skills, want 1", len(items))
	}
	if items[0].ID != "core/fast_path" || items[0].Name != "Deterministic Fast Path" || len(items[0].SHA256) != 64 {
		t.Fatalf("unexpected skill: %+v", items[0])
	}
}

package skills

import (
	"sort"
	"strings"
	"unicode"
)

type ResolveQuery struct {
	RequestedID   string   `json:"requested_id,omitempty"`
	RequestedName string   `json:"requested_name,omitempty"`
	Platform      string   `json:"platform,omitempty"`
	Surfaces      []string `json:"surfaces,omitempty"`
	Capabilities  []string `json:"capabilities,omitempty"`
}

type Candidate struct {
	Skill      Skill    `json:"skill"`
	Score      float64  `json:"score"`
	Reasons    []string `json:"reasons"`
	ExactMatch bool     `json:"exact_match"`
}

type Resolution struct {
	Decision       string      `json:"decision"`
	Candidates     []Candidate `json:"candidates"`
	NeedsResearch  bool        `json:"needs_research"`
	AutoMerge      bool        `json:"auto_merge"`
	Ambiguous      bool        `json:"ambiguous"`
	ResolverPolicy string      `json:"resolver_policy"`
}

func (r *Registry) Resolve(q ResolveQuery) (Resolution, error) {
	items, err := r.List()
	if err != nil {
		return Resolution{}, err
	}

	requestedID := normalizeID(q.RequestedID)
	requestedName := normalizeText(q.RequestedName)
	parts := []string{q.RequestedName, q.Platform}
	parts = append(parts, q.Surfaces...)
	parts = append(parts, q.Capabilities...)
	queryTokens := tokenSet(strings.Join(parts, " "))

	candidates := make([]Candidate, 0, len(items))
	for _, item := range items {
		id := normalizeID(item.ID)
		name := normalizeText(item.Name)
		exact := (requestedID != "" && requestedID == id) || (requestedName != "" && requestedName == name)
		reasons := make([]string, 0, 3)
		score := 0.0
		if exact {
			score = 1
			reasons = append(reasons, "exact_id_or_name")
		} else {
			candidateTokens := tokenSet(item.ID + " " + item.Name)
			score = jaccard(queryTokens, candidateTokens)
			if score > 0 {
				reasons = append(reasons, "token_overlap")
			}
		}
		if exact || score > 0 {
			candidates = append(candidates, Candidate{Skill: item, Score: score, Reasons: reasons, ExactMatch: exact})
		}
	}

	sort.Slice(candidates, func(i, j int) bool {
		if candidates[i].Score == candidates[j].Score {
			return candidates[i].Skill.ID < candidates[j].Skill.ID
		}
		return candidates[i].Score > candidates[j].Score
	})
	if len(candidates) > 8 {
		candidates = candidates[:8]
	}

	res := Resolution{
		Decision:       "CREATE_NEW",
		Candidates:     candidates,
		NeedsResearch:  true,
		AutoMerge:      false,
		ResolverPolicy: "REUSE>EXTEND>MERGE>CREATE_NEW; deterministic resolver never auto-merges ambiguous candidates",
	}
	if len(candidates) == 0 {
		return res, nil
	}
	if candidates[0].ExactMatch {
		res.Decision = "REUSE"
		res.NeedsResearch = false
		return res, nil
	}
	if candidates[0].Score >= 0.60 {
		res.Decision = "EXTEND"
		res.NeedsResearch = true
	}
	if len(candidates) > 1 && candidates[0].Score-candidates[1].Score < 0.10 {
		res.Ambiguous = true
		res.NeedsResearch = true
	}
	return res, nil
}

func normalizeID(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	s = strings.ReplaceAll(s, "\\", "/")
	s = strings.Trim(s, "/")
	return s
}

func normalizeText(s string) string {
	return strings.Join(strings.Fields(strings.ToLower(strings.TrimSpace(s))), " ")
}

func tokenSet(s string) map[string]struct{} {
	out := map[string]struct{}{}
	var b strings.Builder
	flush := func() {
		if b.Len() == 0 {
			return
		}
		out[b.String()] = struct{}{}
		b.Reset()
	}
	for _, r := range strings.ToLower(s) {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			b.WriteRune(r)
		} else {
			flush()
		}
	}
	flush()
	return out
}

func jaccard(a, b map[string]struct{}) float64 {
	if len(a) == 0 || len(b) == 0 {
		return 0
	}
	intersection := 0
	union := make(map[string]struct{}, len(a)+len(b))
	for k := range a {
		union[k] = struct{}{}
		if _, ok := b[k]; ok {
			intersection++
		}
	}
	for k := range b {
		union[k] = struct{}{}
	}
	return float64(intersection) / float64(len(union))
}

package tasks

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"sort"
	"strings"
	"time"
)

type Input struct {
	Platform      string   `json:"platform"`
	Surfaces      []string `json:"surfaces"`
	Niche         string   `json:"niche"`
	Geo           string   `json:"geo,omitempty"`
	Language      string   `json:"language"`
	ContentType   string   `json:"content_type"`
	Goal          string   `json:"goal"`
	TargetQueries []string `json:"target_queries,omitempty"`
}

type Task struct {
	ID          string    `json:"id"`
	Fingerprint string    `json:"fingerprint"`
	Input       Input     `json:"input"`
	CreatedAt   time.Time `json:"created_at"`
}

func New(in Input) (Task, error) {
	in = normalize(in)
	if err := validate(in); err != nil {
		return Task{}, err
	}
	b, err := json.Marshal(in)
	if err != nil {
		return Task{}, err
	}
	sum := sha256.Sum256(b)
	fingerprint := hex.EncodeToString(sum[:])
	return Task{
		ID:          "tsk_" + fingerprint[:16],
		Fingerprint: fingerprint,
		Input:       in,
		CreatedAt:   time.Now().UTC(),
	}, nil
}

func normalize(in Input) Input {
	in.Platform = token(in.Platform)
	in.Niche = canonicalText(in.Niche)
	in.Geo = canonicalText(in.Geo)
	in.Language = token(in.Language)
	in.ContentType = token(in.ContentType)
	in.Goal = token(in.Goal)
	in.Surfaces = normalizedSet(in.Surfaces)
	in.TargetQueries = normalizedTextSet(in.TargetQueries)
	return in
}

func validate(in Input) error {
	if in.Platform == "" {
		return errors.New("platform is required")
	}
	if len(in.Surfaces) == 0 {
		return errors.New("at least one surface is required")
	}
	if in.Niche == "" {
		return errors.New("niche is required")
	}
	if in.Language == "" {
		return errors.New("language is required")
	}
	if in.ContentType == "" {
		return errors.New("content_type is required")
	}
	if in.Goal == "" {
		return errors.New("goal is required")
	}
	return nil
}

func token(s string) string {
	s = canonicalText(s)
	s = strings.Join(strings.Fields(s), "_")
	return s
}

func canonicalText(s string) string {
	return strings.ToLower(strings.Join(strings.Fields(strings.TrimSpace(s)), " "))
}

func normalizedSet(in []string) []string {
	seen := map[string]struct{}{}
	out := make([]string, 0, len(in))
	for _, item := range in {
		item = token(item)
		if item == "" {
			continue
		}
		if _, ok := seen[item]; ok {
			continue
		}
		seen[item] = struct{}{}
		out = append(out, item)
	}
	sort.Strings(out)
	return out
}

func normalizedTextSet(in []string) []string {
	seen := map[string]struct{}{}
	out := make([]string, 0, len(in))
	for _, item := range in {
		item = canonicalText(item)
		if item == "" {
			continue
		}
		if _, ok := seen[item]; ok {
			continue
		}
		seen[item] = struct{}{}
		out = append(out, item)
	}
	sort.Strings(out)
	return out
}

package tasks

import "testing"

func TestTaskFingerprintNormalizesEquivalentInput(t *testing.T) {
	a, err := New(Input{
		Platform: " Yandex ", Surfaces: []string{"Neuro", "organic", "NEURO"}, Niche: " flowers ",
		Language: "RU", ContentType: "Article", Goal: "Rank And Cite",
		TargetQueries: []string{"букет  1 сентября", "Букет 1 сентября"},
	})
	if err != nil {
		t.Fatal(err)
	}
	b, err := New(Input{
		Platform: "yandex", Surfaces: []string{"organic", "neuro"}, Niche: "flowers",
		Language: "ru", ContentType: "article", Goal: "rank and cite",
		TargetQueries: []string{"Букет 1 сентября"},
	})
	if err != nil {
		t.Fatal(err)
	}
	if a.Fingerprint != b.Fingerprint {
		t.Fatalf("fingerprints differ: %s != %s", a.Fingerprint, b.Fingerprint)
	}
}

func TestTaskRequiresCoreFields(t *testing.T) {
	if _, err := New(Input{}); err == nil {
		t.Fatal("expected validation error")
	}
}

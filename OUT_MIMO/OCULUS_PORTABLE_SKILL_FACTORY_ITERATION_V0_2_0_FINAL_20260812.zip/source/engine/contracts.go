package engine

type ClaimClass string

const (
	ClaimPlatformFact     ClaimClass = "PLATFORM_FACT"
	ClaimEmpiricalPattern ClaimClass = "EMPIRICAL_PATTERN"
	ClaimHypothesis       ClaimClass = "HYPOTHESIS"
	ClaimAntiPattern      ClaimClass = "ANTI_PATTERN"
	ClaimExperiment       ClaimClass = "EXPERIMENT"
	ClaimRetracted        ClaimClass = "RETRACTED"
)

type SkillDecision string

const (
	DecisionReuse     SkillDecision = "REUSE"
	DecisionExtend    SkillDecision = "EXTEND"
	DecisionMerge     SkillDecision = "MERGE"
	DecisionCreateNew SkillDecision = "CREATE_NEW"
	DecisionReject    SkillDecision = "REJECT"
)

type Task struct {
	ID       string         `json:"id"`
	Platform string         `json:"platform"`
	Surface  string         `json:"surface"`
	Niche    string         `json:"niche,omitempty"`
	Geo      string         `json:"geo,omitempty"`
	Language string         `json:"language,omitempty"`
	Goal     string         `json:"goal"`
	Input    map[string]any `json:"input,omitempty"`
}

type EvidenceRef struct {
	ID         string  `json:"id"`
	Source     string  `json:"source"`
	SHA256     string  `json:"sha256,omitempty"`
	Stance     string  `json:"stance,omitempty"`
	Confidence float64 `json:"confidence,omitempty"`
}

type SkillResolution struct {
	Decision            SkillDecision `json:"decision"`
	SkillIDs            []string      `json:"skill_ids,omitempty"`
	MissingCapabilities []string      `json:"missing_capabilities,omitempty"`
	Evidence            []EvidenceRef `json:"evidence,omitempty"`
	TraceID             string        `json:"trace_id,omitempty"`
}

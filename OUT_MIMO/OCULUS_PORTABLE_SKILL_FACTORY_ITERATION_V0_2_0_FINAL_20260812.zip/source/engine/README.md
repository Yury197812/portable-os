# engine

Public/core contracts for OCULUS Skill Factory.

The engine is responsible for the semantic lifecycle:

`TASK → CLASSIFY → RESOLVE → GAP → RESEARCH → EVIDENCE → DEDUP → COMPILE → VALIDATE → BATTLECHECK → APPLY → OUTCOME`.

Implementation rule: accelerated paths are optional candidates behind equivalence gates. Reference behavior and evidence/provenance completeness remain the oracle until a candidate is promoted.

Low-level implementation details may live under `internal/`, but durable engine contracts belong here so API, dashboard, tests and future adapters share the same vocabulary.

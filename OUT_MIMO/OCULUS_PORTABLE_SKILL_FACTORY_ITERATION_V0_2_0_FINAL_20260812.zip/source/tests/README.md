# tests

Cross-package and product-level verification lives here.

Required future suites:

- clean-machine portable smoke;
- relocated-folder smoke;
- network deny/redirect/timeout/oversize cases;
- source/evidence integrity;
- MIMO conflicting-batch ingestion;
- crash/interrupted-write recovery;
- reference-vs-fast-path equivalence;
- incremental-vs-full-build equivalence;
- performance benchmarks with accuracy gates;
- release manifest and rollback verification.

Package-local unit tests remain beside Go packages under `internal/` and `engine/`.

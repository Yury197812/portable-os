# VSCode + GitHub Access Info

## GitHub Account
- **Username**: Yury197812
- **Email**: apohob5@gmail.com
- **Password**: Klin120478!+123

## API Token (for Git operations)
```
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
```

## Setup in VSCode

### 1. Clone Repository
1. Open VSCode
2. Press `Ctrl+Shift+P` → "Git: Clone"
3. Enter URL:
```
https://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@github.com/Yury197812/portable-os.git
```

### 2. Configure Git Credentials
Open terminal in VSCode (`Ctrl+`) and run:
```bash
git config --global user.name "Yury197812"
git config --global user.email "apohob5@gmail.com"
```

### 3. Store Token for Push/Pull
```bash
git remote set-url origin https://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@github.com/Yury197812/portable-os.git
```

### 4. GitHub Extension (Optional)
1. Install "GitHub" extension in VSCode
2. Sign in with token: `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`

## Repositories
- `portable-os` — Main project (private)
- `science-books-1001-proofs`
- `cdp_rs`
- `portable-blocks`

## Important Notes
1. Token works for all git operations (clone, pull, push)
2. Do NOT use browser login — requires 2FA on phone
3. Token may expire — regenerate at https://github.com/settings/tokens

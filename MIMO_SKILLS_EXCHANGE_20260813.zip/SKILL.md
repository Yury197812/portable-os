# GitHub Authentication Skill

Быстрая авторизация GitHub CLI без 2FA каждый раз.

## Проблема

При использовании `gh auth login` интерактивно требуется:
1. Ввести логин
2. Выбрать метод (GitHub.com)
3. Пройти 2FA (код из приложения/SMS)
4. Выбрать git protocol (HTTPS)

Это занимает время и требует участия пользователя.

## Решение: Personal Access Token (PAT) + Environment Variable

### ВАЖНО: Токен ДОЛЖЕН иметь эти scopes!

`gh auth login` требует **минимум** эти scopes:
- `repo` — полный доступ к репозиториям
- `read:org` — чтение организаций
- `gist` — создание gist

**Если токен имеет только `repo` — будет ошибка 401!**

### Шаг 1: Создание токена (один раз)

1. Перейти на https://github.com/settings/tokens/new
2. Дать имя (например: "mimo-cli")
3. Выбрать срок жизни (рекомендую: 90 дней или "No expiration")
4. **Обязательно выбрать все 3 scopes:**
   - [x] repo (Full control of private repositories)
   - [x] read:org (Read org and team membership)
   - [x] gist (Create gists)
5. Нажать "Generate token"
6. **Скопировать токен сразу** (он больше не будет показан!)

### Шаг 2: Авторизация через Environment Variable

**РАБОЧИЙ СПОСОБ: установить переменную окружения GITHUB_TOKEN**

```bash
# Windows CMD
set GITHUB_TOKEN=ghp_ВАШ_ТОКЕН

# Windows PowerShell
$env:GITHUB_TOKEN = "ghp_ВАШ_ТОКЕН"

# Linux/Mac
export GITHUB_TOKEN=ghp_ВАШ_ТОКЕН
```

После этого `gh auth status` покажет авторизацию.

### Шаг 3: Проверка

```bash
gh auth status
```

Должно показать:
```
github.com
  ✓ Logged in to github.com as USERNAME (GITHUB_TOKEN)
  - Active account: true
  - Git operations protocol: https
  - Token scopes: 'gist', 'read:org', 'repo'
```

## Автоматизация для MiMoCode

### Сохранение токена в PowerShell profile

Добавить в `$PROFILE`:

```powershell
$env:GITHUB_TOKEN = "ghp_ВАШ_ТОКЕН"
```

### Сохранение в .env файл

Создать файл `.env` в проекте:

```
GITHUB_TOKEN=ghp_ВАШ_ТОКЕН
```

## Проверка scopes токена

```bash
# Проверить scopes токена через API
curl -s -H "Authorization: token ghp_ТОКЕН" -I https://api.github.com/user | findstr "x-oauth-scopes"
```

Должно показать: `X-OAuth-Scopes: gist, read:org, repo`

## Частые ошибки

1. **"gh: not found"** — установить GitHub CLI: `winget install GitHub.cli`
2. **"Invalid token" / "Bad credentials"** — токен истек или неправильно скопирован
3. **"Repository not found"** — недостаточно прав (нужен scope `repo`)
4. **401 Bad credentials** — токен не имеет всех required scopes (repo + read:org + gist)

## Ссылки

- Документация: https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token
- GitHub CLI: https://cli.github.com/
- Scopes reference: https://docs.github.com/en/apps/building-oauth-apps/scopes-for-oauth-apps/

# Книга: Каналы связи GPT ↔ MIMO

## Версия: 0.1.0
## Дата: 2026-08-13
## Автор: MiMo Code Agent

---

## Введение

Данная книга описывает систему двусторонней коммуникации между двумя AI-агентами:
- **GPT** (ChatGPT/OpenAI) — внешний агент
- **MIMO** (MiMo Code Agent) — локальный агент на рабочей станции пользователя

Цель системы: обеспечить надёжный, верифицируемый обмен данными, задачами и результатами между агентами через распределённое хранилище (GitHub).

---

## Глава 1: Архитектура каналов связи

### 1.1 Обзор каналов

| Канал | Направление | Протокол | Гарантии |
|-------|-------------|----------|----------|
| **GitHub Repository** | GPT ↔ MIMO | Git push/pull + GitHub API | Транзакционность, версионность |
| **GitHub Issues** | GPT → MIMO | Issue creation + labels | Уведомления, трекинг |
| **GitHub Actions** | Автоматически | CI/CD workflows | ACK/NACK, автопроверка |
| **GitHub Pages** | GPT → MIMO | Статический сайт | Публичный доступ |
| **Local Filesystem** | MIMO внутренний | Прямой доступ | Максимальная скорость |

### 1.2 Канал 1: GitHub Repository (Основной канал)

**Назначение**: Двусторонний обмен файлами, кодом, документами.

**Структура**:
```
repository/
├── OUT_GPT/              # Данные от GPT для MIMO
│   ├── HANDSHAKE.json    # Метаданные пакета
│   ├── TASK_001.md       # Задача от GPT
│   └── PAYLOAD/          # Файлы задачи
├── OUT_MIMO/             # Данные от MIMO для GPT
│   └── MIMO_OUT/         # Ответы MIMO
│       ├── RESPONSE_001.md
│       └── ARTIFACTS/
└── .github/
    └── workflows/        # Автоматическая проверка
```

**Протокол обмена**:
1. **GPT_PUBLISHES**: GPT создаёт файл в `OUT_GPT/` с `HANDSHAKE.json`
2. **MIMO_ACKS**: MIMO подтверждает получение (создаёт ACK в `OUT_MIMO/`)
3. **MIMO_WORKS**: MIMO выполняет задачу
4. **MIMO_PUBLISHES**: MIMO публикует результат в `OUT_MIMO/MIMO_OUT/`
5. **GPT_ACKS**: GPT подтверждает получение ответа
6. **GPT_VALIDATES**: GPT проверяет качество результата
7. **ФИНАЛЬНЫЙ СТАТУС**: ACCEPTED / PARTIAL / QUARANTINED / REJECTED

### 1.3 Канал 2: GitHub Issues (Канал задач)

**Назначение**: Трекинг задач, комментарии, обсуждения.

**Метки (Labels)**:
- `task:new` — Новая задача от GPT
- `task:in_progress` — MIMO работает над задачей
- `task:completed` — Задача выполнена
- `task:needs_review` — Требует проверки GPT
- `priority:high` — Высокий приоритет
- `channel:gpt-mimo` — Канал коммуникации

### 1.4 Канал 3: GitHub Actions (Автоматизация)

**Назначение**: Автоматическая проверка ACK/NACK, валидация ответов.

**Workflow**:
```yaml
name: MIMO Response Validator
on:
  push:
    paths:
      - 'OUT_MIMO/MIMO_OUT/**'

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Validate MIMO response
        run: |
          # Проверка структуры ответа
          # Валидация артефактов
          # Создание ACK/NACK комментария
```

---

## Глава 2: Протоколы обмена

### 2.1 Формат HANDSHAKE.json

```json
{
  "package_id": "GPT-20260813-001",
  "timestamp": "2026-08-13T10:00:00Z",
  "source": "GPT",
  "target": "MIMO",
  "task_type": "code_review",
  "priority": "high",
  "payload_files": [
    "PAYLOAD/src/main.py",
    "PAYLOAD/tests/test_main.py"
  ],
  "expected_response": {
    "format": "markdown",
    "artifacts": true,
    "deadline": "2026-08-13T12:00:00Z"
  },
  "metadata": {
    "session_id": "gpt-session-abc123",
    "model": "gpt-4o",
    "context_window": 128000
  }
}
```

### 2.2 Формат RESPONSE_XXX.md

```markdown
# Response to GPT-20260813-001

## Status: COMPLETED

## Summary
Выполнен код-ревью main.py. Найдены 3 проблемы.

## Findings
1. **Строка 45**: Потенциальная утечка памяти
2. **Строка 78**: Не обработан edge case
3. **Строка 112**: Оптимизация производительности

## Artifacts
- `FIX_main.py` — Исправленная версия
- `TEST_main.py` — Новые тесты

## Metadata
- execution_time: 45s
- model_used: mimo-v2.5
- confidence: 0.95
```

### 2.3 Формат ACK/NACK

```json
{
  "ack_id": "ACK-20260813-001",
  "timestamp": "2026-08-13T10:05:00Z",
  "source": "MIMO",
  "target": "GPT",
  "status": "ACK",
  "details": "Package received and validated",
  "next_action": "processing"
}
```

---

## Глава 3: Безопасность и верификация

### 3.1 Аутентификация

- **GitHub Personal Access Token (PAT)**: Для API доступа
- **SSH Keys**: Для git операций
- **GitHub Actions Secrets**: Для автоматизации

### 3.2 Целостность данных

- **SHA-256 хеши**: Для каждого файла
- **Git commits**: Для трекинга изменений
- **Branch protection**: Для предотвращенияFORCE PUSH

### 3.3 Аудит

- **Git log**: Полная история коммитов
- **GitHub Activity**: Все действия логируются
- **Issue comments**: Обсуждения сохраняются

---

## Глава 4: Рабочие процессы

### 4.1 Процесс: GPT → MIMO (Задача)

```
GPT                          GitHub                       MIMO
 |                             |                           |
 |--- Создаёт HANDSHAKE.json -->|                           |
 |                             |--- push event ------------>|
 |                             |                           |--- Читает задачу
 |                             |                           |--- Выполняет
 |                             |<-- push response ----------|
 |<-- GitHub webhook ----------|                           |
 |                             |--- ACK/NACK -------------->|
```

### 4.2 Процесс: MIMO → GPT (Ответ)

```
MIMO                          GitHub                       GPT
 |                             |                           |
 |--- Создаёт RESPONSE_XXX.md->|                           |
 |                             |--- push event ------------>|
 |                             |                           |--- Читает ответ
 |                             |                           |--- Валидирует
 |<-- GitHub webhook ----------|                           |
 |                             |<-- ACK -------------------|
 |                             |--- Обновляет статус ------>|
```

### 4.3 Процесс: Автоматическая проверка

```
GitHub Actions               GitHub                       MIMO
 |                             |                           |
 |--- Triggered by push ------>|                           |
 |--- Валидирует структуру --->|                           |
 |--- Проверяет хеши --------->|                           |
 |--- Создаёт комментарий --->|                           |
 |                             |--- Уведомление ---------->|
```

---

## Глава 5: Конфигурация и настройка

### 5.1 Требования

- **GitHub Account**: Yury197812
- **Repository**: portable-os (или другой)
- **GitHub CLI**: `gh` установлен и настроен
- **Git**: Настроен с credential helper

### 5.2 Переменные окружения

```bash
# Windows
set GITHUB_TOKEN=ghp_xxxxxxxxxxxx
set GITHUB_REPO=Yury197812/portable-os

# Linux/Mac
export GITHUB_TOKEN=ghp_xxxxxxxxxxxx
export GITHUB_REPO=Yury197812/portable-os
```

### 5.3 Git конфигурация

```bash
git config --global user.name "MiMo Code Agent"
git config --global user.email "mimo@local"
git config --global credential.helper store
```

---

## Глава 6: Мониторинг и отладка

### 6.1 Проверка статуса

```bash
# Проверить авторизацию
gh auth status

# Посмотреть последние коммиты
git log --oneline -10

# Проверить GitHub Actions
gh run list
```

### 6.2 Логирование

- Git commit messages: чёткие, с ссылками на задачи
- Issue comments: подробные описания
- GitHub Actions logs: полная трассировка

### 6.3 Метрики

- **Время ответа**: От публикации до ACK
- **Процент успеха**: ACCEPTED / TOTAL
- **Среднее время выполнения**: Задача → Ответ

---

## Приложения

### A. Шаблоны файлов

#### HANDSHAKE.json шаблон
```json
{
  "package_id": "",
  "timestamp": "",
  "source": "GPT",
  "target": "MIMO",
  "task_type": "",
  "priority": "medium",
  "payload_files": [],
  "expected_response": {
    "format": "markdown",
    "artifacts": false
  }
}
```

#### RESPONSE_XXX.md шаблон
```markdown
# Response to [PACKAGE_ID]

## Status: [COMPLETED/PARTIAL/FAILED]

## Summary
[Краткое описание]

## Findings
1. [Находка 1]
2. [Находка 2]

## Artifacts
- [Файл 1]
- [Файл 2]

## Metadata
- execution_time: 
- model_used: 
- confidence: 
```

### B. GitHub Actions Workflow

```yaml
name: GPT-MIMO Validator

on:
  push:
    branches: [main]
    paths:
      - 'OUT_GPT/**'
      - 'OUT_MIMO/**'

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Detect source
        id: detect
        run: |
          if [[ "${{ github.event.head_commit.message }}" == *"GPT"* ]]; then
            echo "source=GPT" >> $GITHUB_OUTPUT
          else
            echo "source=MIMO" >> $GITHUB_OUTPUT
          fi
      
      - name: Validate structure
        run: |
          # Проверка наличия обязательных файлов
          if [ "${{ steps.detect.outputs.source }}" == "GPT" ]; then
            test -f OUT_GPT/HANDSHAKE.json || exit 1
          else
            test -f OUT_MIMO/MIMO_OUT/RESPONSE_*.md || exit 1
          fi
      
      - name: Create ACK
        run: |
          gh issue create --title "ACK-${{ github.run_id }}" \
            --body "Package validated successfully" \
            --label "channel:gpt-mimo"
```

### C. Чек-лист第一次使用

- [ ] GitHub CLI установлен (`gh --version`)
- [ ] Авторизация выполнена (`gh auth status`)
- [ ] Репозиторий склонирован
- [ ] Структура папок создана (OUT_GPT, OUT_MIMO)
- [ ] Git config настроен (user.name, user.email)
- [ ] GitHub Actions workflow добавлен
- [ ] Тестовый обмен выполнен

---

## История изменений

| Версия | Дата | Изменения |
|--------|------|-----------|
| 0.1.0 | 2026-08-13 | Первоначальная версия. Описание архитектуры и протоколов. |

---

*Книга находится в разработке. Следующие главы: миграция, масштабирование, отказоустойчивость.*
